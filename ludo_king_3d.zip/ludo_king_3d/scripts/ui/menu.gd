class_name Menu
extends Control
## Home screen + settings page. Rebuilt whenever language/theme changes.

signal start_game

var page := "main"

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_build()

func _build() -> void:
	for c in get_children():
		c.queue_free()
	var th := Themes.get_theme(Settings.theme_idx)
	var bg := ColorRect.new()
	bg.color = th.bg
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var scroll := ScrollContainer.new()
	scroll.set_anchors_preset(Control.PRESET_FULL_RECT)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(scroll)
	var margin := MarginContainer.new()
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for s in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + s, 36)
	margin.add_theme_constant_override("margin_top", 70)
	margin.add_theme_constant_override("margin_bottom", 50)
	scroll.add_child(margin)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 18)
	margin.add_child(v)
	v.add_child(UI.label("LUDO KING 3D", 76, Color("ffd24a")))
	v.add_child(UI.label(Settings.tx("sub"), 28, Color("ffffff")))
	v.add_child(_theme_row(th))
	if page == "main":
		_main_page(v)
	else:
		_settings_page(v)

func _theme_row(th: Dictionary) -> Control:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	var sw := HBoxContainer.new()
	sw.alignment = BoxContainer.ALIGNMENT_CENTER
	sw.add_theme_constant_override("separation", 10)
	for c in [th.board, th.cell, th.p[0], th.p[1], th.p[2], th.p[3]]:
		var r := ColorRect.new()
		r.color = c
		r.custom_minimum_size = Vector2(60, 36)
		sw.add_child(r)
	box.add_child(sw)
	var names := []
	for i in Themes.count():
		names.append(Themes.get_theme(i).name)
	box.add_child(UI.label(Settings.tx("theme"), 24, Color(1, 1, 1, 0.7)))
	box.add_child(UI.cycler(names, Settings.theme_idx, func(i):
		Settings.theme_idx = i
		Settings.save_all()
		_build()))
	return box

func _row(parent: Node, title: String, ctl: Control) -> void:
	parent.add_child(UI.label(title, 24, Color(1, 1, 1, 0.75)))
	parent.add_child(ctl)

func _main_page(v: VBoxContainer) -> void:
	v.add_child(UI.label(Settings.tx("profile", [Settings.coins, Settings.wins, Settings.games]), 24, Color("ffcf5c")))
	_row(v, Settings.tx("players"), UI.cycler(["2", "3", "4"], Settings.players_count - 2, func(i):
		Settings.players_count = i + 2
		Settings.save_all()))
	_row(v, Settings.tx("difficulty"), UI.cycler([Settings.tx("easy"), Settings.tx("medium"), Settings.tx("expert")], Settings.ai_level, func(i):
		Settings.ai_level = i
		Settings.save_all()))
	_row(v, Settings.tx("dice_mode"), UI.cycler([Settings.tx("m_classic"), Settings.tx("m_anti"), Settings.tx("m_custom")], Settings.dice_mode, func(i):
		Settings.dice_mode = i
		Settings.save_all()))
	var b1 := UI.button(Settings.tx("play_cpu"), Vector2(0, 100), 36, Color("e0592a"))
	b1.pressed.connect(func():
		Settings.game_mode = 0
		Settings.save_all()
		start_game.emit())
	var b2 := UI.button(Settings.tx("pass_play"), Vector2(0, 100), 36, Color("2f9e63"))
	b2.pressed.connect(func():
		Settings.game_mode = 1
		Settings.save_all()
		start_game.emit())
	var b3 := UI.button(Settings.tx("settings"), Vector2(0, 90), 32, Color("2f7de1"))
	b3.pressed.connect(func():
		page = "settings"
		_build())
	v.add_child(b1)
	v.add_child(b2)
	v.add_child(b3)
	for k in ["online", "tourney"]:
		var d := UI.button(Settings.tx(k), Vector2(0, 80), 26, Color("45566e"))
		d.disabled = true
		v.add_child(d)

func _settings_page(v: VBoxContainer) -> void:
	_row(v, Settings.tx("language"), UI.cycler(["English", "हिन्दी"], 1 if Settings.lang == "hi" else 0, func(i):
		Settings.lang = "hi" if i == 1 else "en"
		Settings.save_all()
		_build()))
	v.add_child(UI.toggle(Settings.tx("music") + ": " + Settings.tx("on"), Settings.tx("music") + ": " + Settings.tx("off"), Settings.music_on, func(s):
		Settings.music_on = s
		Settings.save_all()
		AudioMgr.apply_volumes()))
	v.add_child(UI.toggle(Settings.tx("sound") + ": " + Settings.tx("on"), Settings.tx("sound") + ": " + Settings.tx("off"), Settings.sfx_on, func(s):
		Settings.sfx_on = s
		Settings.save_all()))
	v.add_child(UI.toggle(Settings.tx("vibration") + ": " + Settings.tx("on"), Settings.tx("vibration") + ": " + Settings.tx("off"), Settings.vibration, func(s):
		Settings.vibration = s
		Settings.save_all()))
	_row(v, Settings.tx("master_vol"), UI.slider(Settings.master, func(x):
		Settings.master = x
		AudioMgr.apply_volumes()
		Settings.save_all()))
	_row(v, Settings.tx("music_vol"), UI.slider(Settings.music, func(x):
		Settings.music = x
		AudioMgr.apply_volumes()
		Settings.save_all()))
	_row(v, Settings.tx("sfx_vol"), UI.slider(Settings.sfx, func(x):
		Settings.sfx = x
		Settings.save_all()
		AudioMgr.play("move")))
	var speeds := [0.75, 1.0, 1.6]
	_row(v, Settings.tx("speed"), UI.cycler([Settings.tx("slow"), Settings.tx("normal"), Settings.tx("fast")], speeds.find(Settings.speed) if speeds.has(Settings.speed) else 1, func(i):
		Settings.speed = speeds[i]
		Settings.save_all()))
	v.add_child(UI.label(Settings.tx("m_custom"), 28, Color("ffd24a")))
	v.add_child(UI.toggle(Settings.tx("c_open") + ": " + Settings.tx("on"), Settings.tx("c_open") + ": " + Settings.tx("off"), Settings.custom_opening, func(s):
		Settings.custom_opening = s
		Settings.save_all()))
	v.add_child(UI.toggle(Settings.tx("c_track") + ": " + Settings.tx("on"), Settings.tx("c_track") + ": " + Settings.tx("off"), Settings.custom_track, func(s):
		Settings.custom_track = s
		Settings.save_all()))
	v.add_child(UI.toggle(Settings.tx("c_lane") + ": " + Settings.tx("on"), Settings.tx("c_lane") + ": " + Settings.tx("off"), Settings.custom_lane, func(s):
		Settings.custom_lane = s
		Settings.save_all()))
	var back := UI.button(Settings.tx("back"), Vector2(0, 90), 32, Color("8a3a3a"))
	back.pressed.connect(func():
		page = "main"
		_build())
	v.add_child(back)
