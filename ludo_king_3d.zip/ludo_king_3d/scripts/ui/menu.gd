class_name Menu
extends Control
## Home screen + settings page. Rebuilt whenever language/theme changes.

signal start_game
signal built

var page := "main"

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_build()

func _build() -> void:
	for c in get_children():
		c.queue_free()
	var th := Themes.get_theme(Settings.theme_idx)
	var bg := TextureRect.new()
	var g := Gradient.new()
	g.colors = PackedColorArray([(th.bg as Color).lightened(0.25), th.bg, (th.bg as Color).darkened(0.55)])
	g.offsets = PackedFloat32Array([0.0, 0.45, 1.0])
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill_from = Vector2(0.5, 0.0)
	gt.fill_to = Vector2(0.5, 1.0)
	gt.width = 8
	gt.height = 256
	bg.texture = gt
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_SCALE
	add_child(bg)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(scroll)
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var margin := MarginContainer.new()
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for s in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + s, 30)
	margin.add_theme_constant_override("margin_top", 70)
	margin.add_theme_constant_override("margin_bottom", 50)
	scroll.add_child(margin)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 16)
	margin.add_child(v)
	var gold := Color("ffd24a")
	var title := UI.label("LUDO KING 3D", 80, gold)
	title.add_theme_constant_override("outline_size", 14)
	v.add_child(title)
	v.add_child(UI.label(Settings.tx("sub"), 26, Color(1, 1, 1, 0.85)))
	v.add_child(_preview(th))
	var names := []
	for i in Themes.count():
		names.append(Themes.get_theme(i).name)
	v.add_child(UI.cycler(names, Settings.theme_idx, func(i):
		Settings.theme_idx = i
		Settings.save_all()
		_build()))
	var card := UI.card()
	v.add_child(card)
	var cv := VBoxContainer.new()
	cv.add_theme_constant_override("separation", 16)
	card.add_child(cv)
	if page == "main":
		_main_page(cv)
	else:
		_settings_page(cv)
	built.emit()

## Live 3D preview: spinning dice + the four tokens in the selected theme.
func _preview(th: Dictionary) -> Control:
	var c := SubViewportContainer.new()
	c.stretch = true
	c.custom_minimum_size = Vector2(0, 400)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sv := SubViewport.new()
	sv.transparent_bg = true
	sv.own_world_3d = true
	sv.size = Vector2i(660, 400)
	c.add_child(sv)
	var env := Environment.new()
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.9, 0.92, 1.0)
	env.ambient_light_energy = 0.5
	var we := WorldEnvironment.new()
	we.environment = env
	sv.add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, -30, 0)
	sun.light_energy = 1.3
	sv.add_child(sun)
	var cam := Camera3D.new()
	cam.keep_aspect = Camera3D.KEEP_WIDTH
	cam.fov = 48
	cam.position = Vector3(0, 2.6, 8.0)
	sv.add_child(cam)
	cam.look_at(Vector3(0, 0.2, 0))
	var dice := Dice3D.new()
	sv.add_child(dice)
	dice.build(th)
	dice.visible = true
	dice.scale = Vector3.ONE * 1.5
	dice.position = Vector3(0, 1.3, 0)
	var sp := dice.create_tween().set_loops()
	sp.tween_property(dice, "rotation_degrees:y", 360.0, 7.0).as_relative()
	var wob := dice.create_tween().set_loops()
	wob.tween_property(dice, "position:y", 1.6, 1.2).set_trans(Tween.TRANS_SINE)
	wob.tween_property(dice, "position:y", 1.3, 1.2).set_trans(Tween.TRANS_SINE)
	for pl in 4:
		var t := TokenFactory.make(th, pl)
		t.scale = Vector3.ONE * 1.25
		t.position = Vector3(-2.7 + pl * 1.8, -1.3, 1.2)
		sv.add_child(t)
		var bob := t.create_tween().set_loops()
		bob.tween_property(t, "position:y", -1.05, 0.5 + pl * 0.12).set_trans(Tween.TRANS_SINE)
		bob.tween_property(t, "position:y", -1.3, 0.5 + pl * 0.12).set_trans(Tween.TRANS_SINE)
	return c

func _row(parent: Node, title: String, ctl: Control) -> void:
	parent.add_child(UI.label(title, 24, Color(1, 1, 1, 0.75)))
	parent.add_child(ctl)

func _main_page(v: VBoxContainer) -> void:
	v.add_child(UI.label(Settings.tx("profile", [Settings.coins, Settings.wins, Settings.games]), 24, Color("ffcf5c")))
	_row(v, Settings.tx("players"), UI.cycler(["2", "3", "4"], Settings.players_count - 2, func(i):
		Settings.players_count = i + 2
		Settings.save_all()))
	_row(v, Settings.tx("difficulty"), UI.cycler([Settings.tx("easy"), Settings.tx("medium"), Settings.tx("expert")], Settings.ai_level, func(i):
		Settings.ai_level = i
		Settings.save_all()))
	_row(v, Settings.tx("dice_mode"), UI.cycler([Settings.tx("m_classic"), Settings.tx("m_anti"), Settings.tx("m_custom")], Settings.dice_mode, func(i):
		Settings.dice_mode = i
		Settings.save_all()))
	var b1 := UI.button(Settings.tx("play_cpu"), Vector2(0, 100), 36, Color("e0592a"))
	b1.pressed.connect(func():
		Settings.game_mode = 0
		Settings.save_all()
		start_game.emit())
	var b2 := UI.button(Settings.tx("pass_play"), Vector2(0, 100), 36, Color("2f9e63"))
	b2.pressed.connect(func():
		Settings.game_mode = 1
		Settings.save_all()
		start_game.emit())
	var b3 := UI.button(Settings.tx("settings"), Vector2(0, 90), 32, Color("2f7de1"))
	b3.pressed.connect(func():
		page = "settings"
		_build())
	v.add_child(b1)
	v.add_child(b2)
	v.add_child(b3)
	for k in ["online", "tourney"]:
		var d := UI.button(Settings.tx(k), Vector2(0, 80), 26, Color("45566e"))
		d.disabled = true
		v.add_child(d)

func _settings_page(v: VBoxContainer) -> void:
	_row(v, Settings.tx("language"), UI.cycler(["English", "हिन्दी"], 1 if Settings.lang == "hi" else 0, func(i):
		Settings.lang = "hi" if i == 1 else "en"
		Settings.save_all()
		_build()))
	v.add_child(UI.toggle(Settings.tx("music") + ": " + Settings.tx("on"), Settings.tx("music") + ": " + Settings.tx("off"), Settings.music_on, func(s):
		Settings.music_on = s
		Settings.save_all()
		AudioMgr.apply_volumes()))
	v.add_child(UI.toggle(Settings.tx("sound") + ": " + Settings.tx("on"), Settings.tx("sound") + ": " + Settings.tx("off"), Settings.sfx_on, func(s):
		Settings.sfx_on = s
		Settings.save_all()))
	v.add_child(UI.toggle(Settings.tx("vibration") + ": " + Settings.tx("on"), Settings.tx("vibration") + ": " + Settings.tx("off"), Settings.vibration, func(s):
		Settings.vibration = s
		Settings.save_all()))
	_row(v, Settings.tx("master_vol"), UI.slider(Settings.master, func(x):
		Settings.master = x
		AudioMgr.apply_volumes()
		Settings.save_all()))
	_row(v, Settings.tx("music_vol"), UI.slider(Settings.music, func(x):
		Settings.music = x
		AudioMgr.apply_volumes()
		Settings.save_all()))
	_row(v, Settings.tx("sfx_vol"), UI.slider(Settings.sfx, func(x):
		Settings.sfx = x
		Settings.save_all()
		AudioMgr.play("move")))
	var speeds := [0.75, 1.0, 1.6]
	_row(v, Settings.tx("speed"), UI.cycler([Settings.tx("slow"), Settings.tx("normal"), Settings.tx("fast")], speeds.find(Settings.speed) if speeds.has(Settings.speed) else 1, func(i):
		Settings.speed = speeds[i]
		Settings.save_all()))
	v.add_child(UI.label(Settings.tx("m_custom"), 28, Color("ffd24a")))
	v.add_child(UI.toggle(Settings.tx("c_open") + ": " + Settings.tx("on"), Settings.tx("c_open") + ": " + Settings.tx("off"), Settings.custom_opening, func(s):
		Settings.custom_opening = s
		Settings.save_all()))
	v.add_child(UI.toggle(Settings.tx("c_track") + ": " + Settings.tx("on"), Settings.tx("c_track") + ": " + Settings.tx("off"), Settings.custom_track, func(s):
		Settings.custom_track = s
		Settings.save_all()))
	v.add_child(UI.toggle(Settings.tx("c_lane") + ": " + Settings.tx("on"), Settings.tx("c_lane") + ": " + Settings.tx("off"), Settings.custom_lane, func(s):
		Settings.custom_lane = s
		Settings.save_all()))
	var back := UI.button(Settings.tx("back"), Vector2(0, 90), 32, Color("8a3a3a"))
	back.pressed.connect(func():
		page = "main"
		_build())
	v.add_child(back)
