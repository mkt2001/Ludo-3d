class_name IconButton
extends Control
## Round button drawn with shapes only (no text). kinds: home, pause, play, replay, sound, mute

signal pressed

var kind := "home"
var col := Color("2b3a55")
var down := false

func _init(k := "home", c := Color("2b3a55"), s := 84.0) -> void:
	kind = k
	col = c
	custom_minimum_size = Vector2(s, s)
	mouse_filter = Control.MOUSE_FILTER_STOP

func _ready() -> void:
	resized.connect(func(): pivot_offset = size / 2.0)
	pivot_offset = size / 2.0

func set_kind(k: String) -> void:
	kind = k
	queue_redraw()

func _gui_input(e: InputEvent) -> void:
	if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
		if e.pressed:
			down = true
			scale = Vector2(0.9, 0.9)
			AudioMgr.play("click")
			AudioMgr.vibrate(15)
		else:
			if down and Rect2(Vector2.ZERO, size).has_point(e.position):
				pressed.emit()
			down = false
			scale = Vector2.ONE

func _draw() -> void:
	var c := size / 2.0
	var r := minf(size.x, size.y) / 2.0 - 4.0
	draw_circle(c + Vector2(0, 5), r, Color(0, 0, 0, 0.4))
	draw_circle(c, r, col.darkened(0.25))
	draw_circle(c - Vector2(0, 2), r - 3.0, col)
	draw_arc(c, r, 0.0, TAU, 48, Color(1, 1, 1, 0.35), 2.5, true)
	var w := Color.WHITE
	match kind:
		"pause":
			draw_rect(Rect2(c.x - 0.34 * r, c.y - 0.36 * r, 0.22 * r, 0.72 * r), w)
			draw_rect(Rect2(c.x + 0.12 * r, c.y - 0.36 * r, 0.22 * r, 0.72 * r), w)
		"play":
			draw_colored_polygon(PackedVector2Array([c + Vector2(-0.22, -0.4) * r, c + Vector2(-0.22, 0.4) * r, c + Vector2(0.42, 0.0) * r]), w)
		"home":
			draw_colored_polygon(PackedVector2Array([c + Vector2(0, -0.48) * r, c + Vector2(-0.52, 0.0) * r, c + Vector2(0.52, 0.0) * r]), w)
			draw_rect(Rect2(c.x - 0.36 * r, c.y - 0.02 * r, 0.72 * r, 0.46 * r), w)
			draw_rect(Rect2(c.x - 0.1 * r, c.y + 0.18 * r, 0.2 * r, 0.28 * r), col)
		"replay":
			var rr := 0.42 * r
			draw_arc(c, rr, deg_to_rad(-40.0), deg_to_rad(250.0), 32, w, 0.15 * r, true)
			var th := deg_to_rad(250.0)
			var e := c + Vector2(cos(th), sin(th)) * rr
			var d := Vector2(-sin(th), cos(th))
			var pp := Vector2(-d.y, d.x)
			draw_colored_polygon(PackedVector2Array([e + d * 0.26 * r, e + pp * 0.2 * r, e - pp * 0.2 * r]), w)
		"view":
			draw_arc(c, 0.36 * r, 0.0, TAU, 32, w, 0.1 * r, true)
			draw_line(c + Vector2(0, -0.58) * r, c + Vector2(0, -0.2) * r, w, 0.1 * r, true)
			draw_line(c + Vector2(0, 0.58) * r, c + Vector2(0, 0.2) * r, w, 0.1 * r, true)
			draw_line(c + Vector2(-0.58, 0) * r, c + Vector2(-0.2, 0) * r, w, 0.1 * r, true)
			draw_line(c + Vector2(0.58, 0) * r, c + Vector2(0.2, 0) * r, w, 0.1 * r, true)
			draw_circle(c, 0.08 * r, w)
		"sound", "mute":
			draw_colored_polygon(PackedVector2Array([c + Vector2(-0.42, -0.14) * r, c + Vector2(-0.22, -0.14) * r, c + Vector2(0.04, -0.36) * r, c + Vector2(0.04, 0.36) * r, c + Vector2(-0.22, 0.14) * r, c + Vector2(-0.42, 0.14) * r]), w)
			if kind == "sound":
				draw_arc(c + Vector2(0.04, 0) * r, 0.3 * r, deg_to_rad(-45.0), deg_to_rad(45.0), 12, w, 0.09 * r, true)
				draw_arc(c + Vector2(0.04, 0) * r, 0.5 * r, deg_to_rad(-45.0), deg_to_rad(45.0), 12, w, 0.09 * r, true)
			else:
				draw_line(c + Vector2(0.16, -0.22) * r, c + Vector2(0.5, 0.22) * r, Color("ff8a80"), 0.1 * r, true)
				draw_line(c + Vector2(0.5, -0.22) * r, c + Vector2(0.16, 0.22) * r, Color("ff8a80"), 0.1 * r, true)
