class_name Hud
extends CanvasLayer
## In-game overlay: status, scores, dice info panel (available / blocked), roll button, banners, pause.

signal roll_pressed
signal home_pressed
signal restart_pressed
signal pause_changed(is_paused: bool)

var status: Label
var scores: VBoxContainer
var score_labels := {}
var dice_boxes: Array = []
var roll_btn: Button
var banner_lbl: Label
var toast_lbl: Label
var overlay: Control
var banner_tw: Tween
var toast_tw: Tween

func _ready() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	var root := MarginContainer.new()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_theme_constant_override("margin_left", 16)
	root.add_theme_constant_override("margin_right", 16)
	root.add_theme_constant_override("margin_top", 48)
	root.add_theme_constant_override("margin_bottom", 24)
	add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var v := VBoxContainer.new()
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_theme_constant_override("separation", 10)
	root.add_child(v)
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 10)
	var b_home := UI.button(Settings.tx("home"), Vector2(150, 70), 26, Color("8a3a3a"))
	b_home.pressed.connect(func(): home_pressed.emit())
	var b_pause := UI.button(Settings.tx("pause"), Vector2(150, 70), 26, Color("45566e"))
	b_pause.pressed.connect(func(): show_pause(true))
	var b_snd := UI.button("", Vector2(150, 70), 26, Color("45566e"))
	b_snd.text = Settings.tx("sound") + ": " + Settings.tx("on" if Settings.sfx_on else "off")
	b_snd.pressed.connect(func():
		Settings.sfx_on = not Settings.sfx_on
		Settings.music_on = Settings.sfx_on
		AudioMgr.apply_volumes()
		Settings.save_all()
		b_snd.text = Settings.tx("sound") + ": " + Settings.tx("on" if Settings.sfx_on else "off"))
	top.add_child(b_home)
	top.add_child(b_pause)
	top.add_child(b_snd)
	v.add_child(top)
	status = UI.label("", 36)
	v.add_child(status)
	scores = VBoxContainer.new()
	scores.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(scores)
	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(spacer)
	toast_lbl = UI.label("", 30, Color("ffcf5c"))
	toast_lbl.modulate.a = 0.0
	v.add_child(toast_lbl)
	var info := HBoxContainer.new()
	info.alignment = BoxContainer.ALIGNMENT_CENTER
	info.add_theme_constant_override("separation", 8)
	info.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for i in range(1, 7):
		var p := PanelContainer.new()
		p.mouse_filter = Control.MOUSE_FILTER_IGNORE
		p.custom_minimum_size = Vector2(98, 66)
		var l := UI.label(str(i), 30)
		p.add_child(l)
		info.add_child(p)
		dice_boxes.append([p, l])
	v.add_child(info)
	roll_btn = UI.button(Settings.tx("roll"), Vector2(0, 110), 44, Color("e0592a"))
	roll_btn.pressed.connect(func(): roll_pressed.emit())
	v.add_child(roll_btn)
	banner_lbl = UI.label("", 64, Color("fff2a8"))
	banner_lbl.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	banner_lbl.grow_horizontal = Control.GROW_DIRECTION_BOTH
	banner_lbl.grow_vertical = Control.GROW_DIRECTION_BOTH
	banner_lbl.modulate.a = 0.0
	add_child(banner_lbl)
	set_dice_info([1, 2, 3, 4, 5, 6], [])

func set_status(text: String, col := Color.WHITE) -> void:
	status.text = text
	status.add_theme_color_override("font_color", col)

func set_roll_enabled(on: bool) -> void:
	roll_btn.disabled = not on

func set_dice_info(available: Array, blocked: Array) -> void:
	for i in 6:
		var val := i + 1
		var is_blocked := blocked.has(val)
		var col := Color("b3261e") if is_blocked else Color("1f8f4e")
		dice_boxes[i][0].add_theme_stylebox_override("panel", UI.style(col, 14))
		dice_boxes[i][1].text = ("X" + str(val)) if is_blocked else str(val)
		var tw := create_tween()
		dice_boxes[i][0].scale = Vector2(0.85, 0.85)
		dice_boxes[i][0].pivot_offset = dice_boxes[i][0].size / 2
		tw.tween_property(dice_boxes[i][0], "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK)

## entries: [{pl, name, color, home, kills}]
func set_scores(entries: Array, active_pl: int) -> void:
	for e in entries:
		if not score_labels.has(e.pl):
			var l := UI.label("", 24, e.color, HORIZONTAL_ALIGNMENT_LEFT)
			scores.add_child(l)
			score_labels[e.pl] = l
		var lb: Label = score_labels[e.pl]
		lb.text = ("> " if e.pl == active_pl else "   ") + e.name + "   " + Settings.tx("hud_score", [e.home, e.kills])

func banner(text: String, col := Color("fff2a8")) -> void:
	banner_lbl.text = text
	banner_lbl.add_theme_color_override("font_color", col)
	banner_lbl.pivot_offset = banner_lbl.size / 2
	if banner_tw:
		banner_tw.kill()
	banner_lbl.scale = Vector2(0.6, 0.6)
	banner_tw = create_tween()
	banner_tw.set_parallel(true)
	banner_tw.tween_property(banner_lbl, "modulate:a", 1.0, 0.15)
	banner_tw.tween_property(banner_lbl, "scale", Vector2.ONE, 0.3).set_trans(Tween.TRANS_BACK)
	banner_tw.chain().tween_interval(0.8)
	banner_tw.chain().tween_property(banner_lbl, "modulate:a", 0.0, 0.3)

func toast(text: String) -> void:
	toast_lbl.text = text
	if toast_tw:
		toast_tw.kill()
	toast_tw = create_tween()
	toast_tw.tween_property(toast_lbl, "modulate:a", 1.0, 0.2)
	toast_tw.tween_interval(1.3)
	toast_tw.tween_property(toast_lbl, "modulate:a", 0.0, 0.4)

func _clear_overlay() -> void:
	if overlay:
		overlay.queue_free()
		overlay = null

func _make_overlay(title: String) -> VBoxContainer:
	_clear_overlay()
	overlay = ColorRect.new()
	overlay.color = Color(0, 0, 0, 0.7)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(overlay)
	var c := CenterContainer.new()
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(c)
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UI.style(Color("1b2433"), 28))
	c.add_child(p)
	var v := VBoxContainer.new()
	v.custom_minimum_size = Vector2(520, 0)
	v.add_theme_constant_override("separation", 16)
	p.add_child(v)
	v.add_child(UI.label(title, 48, Color("ffd24a")))
	return v

func show_pause(on: bool) -> void:
	if not on:
		_clear_overlay()
		pause_changed.emit(false)
		return
	pause_changed.emit(true)
	var v := _make_overlay(Settings.tx("pause"))
	var b1 := UI.button(Settings.tx("resume"), Vector2(0, 90), 34, Color("2f9e63"))
	b1.pressed.connect(func(): show_pause(false))
	var b2 := UI.button(Settings.tx("restart"), Vector2(0, 90), 34, Color("2f7de1"))
	b2.pressed.connect(func(): restart_pressed.emit())
	var b3 := UI.button(Settings.tx("home"), Vector2(0, 90), 34, Color("8a3a3a"))
	b3.pressed.connect(func(): home_pressed.emit())
	v.add_child(b1)
	v.add_child(b2)
	v.add_child(b3)

func show_result(text: String, col: Color) -> void:
	var v := _make_overlay(text)
	v.get_child(0).add_theme_color_override("font_color", col)
	var b1 := UI.button(Settings.tx("again"), Vector2(0, 90), 34, Color("2f9e63"))
	b1.pressed.connect(func(): restart_pressed.emit())
	var b2 := UI.button(Settings.tx("home"), Vector2(0, 90), 34, Color("8a3a3a"))
	b2.pressed.connect(func(): home_pressed.emit())
	v.add_child(b1)
	v.add_child(b2)
