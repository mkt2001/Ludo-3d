class_name Hud
extends CanvasLayer
## Minimal in-game overlay with no text: home / turn colour badge / sound / pause.

signal home_pressed
signal restart_pressed
signal pause_changed(is_paused: bool)

var badge: Panel
var snd_btn: IconButton
var overlay: Control

func _spacer() -> Control:
	var c := Control.new()
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c

func _ready() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	var root := MarginContainer.new()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for s in ["left", "right", "bottom"]:
		root.add_theme_constant_override("margin_" + s, 24)
	root.add_theme_constant_override("margin_top", 60)
	add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var vb := VBoxContainer.new()
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(vb)
	var top := HBoxContainer.new()
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_theme_constant_override("separation", 14)
	vb.add_child(top)
	var home := IconButton.new("home", Color("8a3a3a"))
	home.pressed.connect(func(): home_pressed.emit())
	top.add_child(home)
	top.add_child(_spacer())
	badge = Panel.new()
	badge.custom_minimum_size = Vector2(70, 70)
	badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(badge)
	set_turn(Color.WHITE)
	top.add_child(_spacer())
	snd_btn = IconButton.new("sound" if Settings.sfx_on else "mute", Color("45566e"))
	snd_btn.pressed.connect(func():
		Settings.sfx_on = not Settings.sfx_on
		Settings.music_on = Settings.sfx_on
		AudioMgr.apply_volumes()
		Settings.save_all()
		snd_btn.set_kind("sound" if Settings.sfx_on else "mute"))
	top.add_child(snd_btn)
	var pause := IconButton.new("pause", Color("45566e"))
	pause.pressed.connect(func(): show_pause(true))
	top.add_child(pause)

func set_turn(col: Color) -> void:
	var s := UI.style(col, 35, Color.WHITE)
	s.set_border_width_all(5)
	badge.add_theme_stylebox_override("panel", s)
	badge.pivot_offset = Vector2(35, 35)
	badge.scale = Vector2(0.6, 0.6)
	create_tween().tween_property(badge, "scale", Vector2.ONE, 0.3).set_trans(Tween.TRANS_BACK)

func _clear_overlay() -> void:
	if overlay:
		overlay.queue_free()
		overlay = null

func _make_overlay() -> VBoxContainer:
	_clear_overlay()
	overlay = ColorRect.new()
	(overlay as ColorRect).color = Color(0, 0, 0, 0.72)
	add_child(overlay)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var c := CenterContainer.new()
	overlay.add_child(c)
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 44)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	c.add_child(v)
	return v

func _row(buttons: Array) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 36)
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	for b in buttons:
		h.add_child(b)
	return h

func show_pause(on: bool) -> void:
	if not on:
		_clear_overlay()
		pause_changed.emit(false)
		return
	pause_changed.emit(true)
	var v := _make_overlay()
	var b1 := IconButton.new("play", Color("2f9e63"), 150.0)
	b1.pressed.connect(func(): show_pause(false))
	var b2 := IconButton.new("replay", Color("2f7de1"), 150.0)
	b2.pressed.connect(func(): restart_pressed.emit())
	var b3 := IconButton.new("home", Color("8a3a3a"), 150.0)
	b3.pressed.connect(func(): home_pressed.emit())
	v.add_child(_row([b1, b2, b3]))

func show_result(col: Color) -> void:
	var v := _make_overlay()
	var crown := Panel.new()
	crown.custom_minimum_size = Vector2(190, 190)
	var s := UI.style(col, 95, Color.WHITE)
	s.set_border_width_all(8)
	crown.add_theme_stylebox_override("panel", s)
	crown.pivot_offset = Vector2(95, 95)
	var tw := crown.create_tween().set_loops()
	tw.tween_property(crown, "scale", Vector2(1.12, 1.12), 0.6).set_trans(Tween.TRANS_SINE)
	tw.tween_property(crown, "scale", Vector2.ONE, 0.6).set_trans(Tween.TRANS_SINE)
	var cc := CenterContainer.new()
	cc.add_child(crown)
	v.add_child(cc)
	var b1 := IconButton.new("replay", Color("2f9e63"), 150.0)
	b1.pressed.connect(func(): restart_pressed.emit())
	var b2 := IconButton.new("home", Color("8a3a3a"), 150.0)
	b2.pressed.connect(func(): home_pressed.emit())
	v.add_child(_row([b1, b2]))
