class_name UI
extends RefCounted
## Small helpers so every screen has the same premium look.

static func style(bg: Color, radius := 22, border := Color(1, 1, 1, 0.28)) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.set_corner_radius_all(radius)
	s.set_border_width_all(2)
	s.border_color = border
	s.content_margin_left = 16
	s.content_margin_right = 16
	s.content_margin_top = 8
	s.content_margin_bottom = 8
	s.shadow_size = 8
	s.shadow_color = Color(0, 0, 0, 0.4)
	return s

static func button(text: String, min_size := Vector2(0, 88), fsize := 32, col := Color("2f7de1")) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.add_theme_font_size_override("font_size", fsize)
	b.add_theme_stylebox_override("normal", style(col))
	b.add_theme_stylebox_override("hover", style(col.lightened(0.15)))
	b.add_theme_stylebox_override("pressed", style(col.darkened(0.3)))
	b.add_theme_stylebox_override("disabled", style(Color(0.25, 0.25, 0.3, 0.85)))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.add_theme_color_override("font_color", Color.WHITE)
	b.add_theme_color_override("font_disabled_color", Color(1, 1, 1, 0.45))
	b.button_down.connect(func():
		AudioMgr.play("click")
		AudioMgr.vibrate(15))
	return b

static func label(text: String, fsize := 28, col := Color.WHITE, align := HORIZONTAL_ALIGNMENT_CENTER) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = align
	l.add_theme_font_size_override("font_size", fsize)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	l.add_theme_constant_override("outline_size", maxi(2, fsize / 8))
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

## "<  value  >" selector. Calls on_change(new_index).
static func cycler(options: Array, current: int, on_change: Callable, fsize := 28) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 8)
	var val := label(str(options[current]), fsize)
	val.custom_minimum_size = Vector2(250, 0)
	val.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	val.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	var idx := [current]
	var prev := button("<", Vector2(80, 76), 36, Color("45566e"))
	var next := button(">", Vector2(80, 76), 36, Color("45566e"))
	prev.pressed.connect(func():
		idx[0] = (idx[0] - 1 + options.size()) % options.size()
		val.text = str(options[idx[0]])
		on_change.call(idx[0]))
	next.pressed.connect(func():
		idx[0] = (idx[0] + 1) % options.size()
		val.text = str(options[idx[0]])
		on_change.call(idx[0]))
	h.add_child(prev)
	h.add_child(val)
	h.add_child(next)
	return h

static func toggle(text_on: String, text_off: String, state: bool, on_change: Callable) -> Button:
	var b := button(text_on if state else text_off, Vector2(0, 76), 28, Color("2f9e63") if state else Color("8a3a3a"))
	var st := [state]
	b.pressed.connect(func():
		st[0] = not st[0]
		b.text = text_on if st[0] else text_off
		b.add_theme_stylebox_override("normal", style(Color("2f9e63") if st[0] else Color("8a3a3a")))
		on_change.call(st[0]))
	return b

static func slider(value: float, on_change: Callable) -> HSlider:
	var s := HSlider.new()
	s.min_value = 0.0
	s.max_value = 1.0
	s.step = 0.05
	s.value = value
	s.custom_minimum_size = Vector2(0, 56)
	s.value_changed.connect(func(v): on_change.call(v))
	return s
