extends Node
## Switches between the menu and a running match.

var menu: Menu
var game: GameController
var hud: Hud

func _ready() -> void:
	get_tree().set_quit_on_go_back(false)
	show_menu()

func _clear() -> void:
	get_tree().paused = false
	for n in [menu, game, hud]:
		if is_instance_valid(n):
			if n is GameController:
				n.gen += 1
			n.queue_free()
	menu = null
	game = null
	hud = null

func show_menu() -> void:
	_clear()
	menu = Menu.new()
	add_child(menu)
	menu.start_game.connect(start_game)
	AudioMgr.start_music()

func start_game() -> void:
	_clear()
	hud = Hud.new()
	game = GameController.new()
	add_child(game)
	add_child(hud)
	game.hud = hud
	hud.home_pressed.connect(show_menu)
	hud.restart_pressed.connect(start_game)
	game.begin()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if is_instance_valid(hud) and is_instance_valid(game) and game.state != "over":
			hud.show_pause(true)
		elif is_instance_valid(game):
			show_menu()
		else:
			get_tree().quit()
