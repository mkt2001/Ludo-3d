extends Node
## Switches between the menu and a running match.
## Scripts are loaded dynamically so a broken script shows a message on screen instead of a blank page.

const BUILD := "BUILD_ID"   # replaced by the GitHub run number

var menu = null
var game = null
var hud = null
var note: Label

func _ready() -> void:
	RenderingServer.set_default_clear_color(Color("141a26"))
	var cl := CanvasLayer.new()
	cl.layer = 100
	add_child(cl)
	note = Label.new()
	note.text = "Ludo King 3D - loading..."
	note.position = Vector2(30, 40)
	note.size = Vector2(660, 200)
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.add_theme_font_size_override("font_size", 28)
	cl.add_child(note)
	var ver := Label.new()
	ver.text = "build " + BUILD
	ver.position = Vector2(20, 1235)
	ver.add_theme_font_size_override("font_size", 22)
	ver.modulate = Color(1, 1, 1, 0.7)
	cl.add_child(ver)
	get_tree().quit_on_go_back = false
	show_menu()

func _make(path: String) -> Object:
	var s = load(path)
	if s == null or not s.can_instantiate():
		note.visible = true
		note.text += "\nSCRIPT ERROR: " + path
		return null
	return s.new()

func _clear() -> void:
	get_tree().paused = false
	for n in [menu, game, hud]:
		if is_instance_valid(n):
			if n.has_method("begin"):
				n.gen += 1
			n.queue_free()
	menu = null
	game = null
	hud = null

func show_menu() -> void:
	_clear()
	menu = _make("res://scripts/ui/menu.gd")
	if menu == null:
		return
	add_child(menu)
	menu.built.connect(func(): note.visible = false)
	menu.start_game.connect(start_game)
	AudioMgr.start_music()

func start_game() -> void:
	_clear()
	hud = _make("res://scripts/ui/hud.gd")
	game = _make("res://scripts/game/game_controller.gd")
	if hud == null or game == null:
		return
	add_child(game)
	add_child(hud)
	game.hud = hud
	hud.home_pressed.connect(show_menu)
	hud.restart_pressed.connect(start_game)
	game.begin()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if is_instance_valid(hud) and is_instance_valid(game) and game.state != "over":
			hud.show_pause(true)
		elif is_instance_valid(game):
			show_menu()
		else:
			get_tree().quit()
