class_name BoardGeo
extends RefCounted
## Board coordinates on a 15x15 grid. World: cell (c,r) -> (c-7, r-7).

const TOKEN_Y := 0.16
const BASE_C := [Vector2(3, 3), Vector2(12, 3), Vector2(12, 12), Vector2(3, 12)]  # Red, Green, Yellow, Blue
const SLOT := [Vector2(-1, -1), Vector2(1, -1), Vector2(-1, 1), Vector2(1, 1)]
const FIN := [Vector3(-1, 0, 0), Vector3(0, 0, -1), Vector3(1, 0, 0), Vector3(0, 0, 1)]
const SAFE := [0, 8, 13, 21, 26, 34, 39, 47]
static var _path: Array = []

static func track() -> Array:
	if _path.is_empty():
		var segs := [[1, 6, 1, 0, 5], [6, 5, 0, -1, 6], [7, 0, 1, 0, 2], [8, 1, 0, 1, 5],
			[9, 6, 1, 0, 6], [14, 7, 0, 1, 2], [13, 8, -1, 0, 5], [8, 9, 0, 1, 6],
			[7, 14, -1, 0, 2], [6, 13, 0, -1, 5], [5, 8, -1, 0, 6], [0, 7, 0, -1, 2]]
		for s in segs:
			for k in range(s[4]):
				_path.append(Vector2i(s[0] + s[2] * k, s[1] + s[3] * k))
	return _path

static func cell_world(c: Vector2i) -> Vector3:
	return Vector3(c.x - 7, TOKEN_Y, c.y - 7)

static func lane_cell(pl: int, k: int) -> Vector2i:
	match pl:
		0: return Vector2i(1 + k, 7)
		1: return Vector2i(7, 1 + k)
		2: return Vector2i(13 - k, 7)
	return Vector2i(7, 13 - k)

static func token_pos(pl: int, p: int, idx: int) -> Vector3:
	if p == GameRules.BASE:
		var b: Vector2 = BASE_C[pl] + SLOT[idx]
		return Vector3(b.x - 7.5, TOKEN_Y, b.y - 7.5)
	if p <= GameRules.LAST_TRACK:
		var c: Vector2i = track()[(GameRules.START_OFFSET[pl] + p) % GameRules.TRACK_LEN]
		return cell_world(c)
	if p < GameRules.FINISHED:
		return cell_world(lane_cell(pl, p - GameRules.HOME_LANE_START))
	var f: Vector3 = FIN[pl]
	return Vector3(f.x, TOKEN_Y, f.z)
