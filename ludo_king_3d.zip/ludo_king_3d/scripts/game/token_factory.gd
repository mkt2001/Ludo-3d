class_name TokenFactory
extends RefCounted
## Builds one glossy 3D token (pawn / diamond / crown-coin depending on theme) with a hidden highlight ring.

static func make(theme: Dictionary, pl: int) -> Node3D:
	var root := Node3D.new()
	var col: Color = theme.p[pl]
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.metallic = clampf(theme.metal, 0.0, 0.6)
	m.roughness = clampf(theme.rough, 0.15, 0.45)
	if theme.glow:
		m.emission_enabled = true
		m.emission = col
		m.emission_energy_multiplier = 0.55
	var dark := StandardMaterial3D.new()
	dark.albedo_color = col.darkened(0.35)
	dark.metallic = m.metallic
	dark.roughness = m.roughness
	var shape: int = theme.shape
	_cyl(root, 0.0, 0.12, 0.44, 0.44, dark)           # base disc
	if shape == 0:                                       # classic pawn
		_cyl(root, 0.12, 0.62, 0.13, 0.33, m)
		_ball(root, 0.92, 0.26, m)
	elif shape == 1:                                     # diamond gem
		var d := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radial_segments = 4
		sm.rings = 2
		sm.radius = 0.4
		sm.height = 1.15
		d.mesh = sm
		d.position.y = 0.72
		d.rotation_degrees.y = 45
		d.material_override = m
		root.add_child(d)
	else:                                                # crown coin
		_cyl(root, 0.12, 0.38, 0.34, 0.36, m)
		_cyl(root, 0.5, 0.3, 0.24, 0.28, dark)
		_ball(root, 0.88, 0.2, m)
	var ring := MeshInstance3D.new()
	ring.name = "ring"
	var rm := CylinderMesh.new()
	rm.top_radius = 0.62
	rm.bottom_radius = 0.62
	rm.height = 0.03
	ring.mesh = rm
	var rmat := StandardMaterial3D.new()
	rmat.albedo_color = Color("fff176")
	rmat.emission_enabled = true
	rmat.emission = Color("fff176")
	rmat.emission_energy_multiplier = 2.6
	ring.material_override = rmat
	ring.position.y = 0.03
	ring.visible = false
	root.add_child(ring)
	return root

static func _cyl(root: Node3D, y: float, h: float, top: float, bottom: float, mat: Material) -> void:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = top
	cm.bottom_radius = bottom
	cm.height = h
	mi.mesh = cm
	mi.position.y = y + h / 2.0
	mi.material_override = mat
	root.add_child(mi)

static func _ball(root: Node3D, y: float, r: float, mat: Material) -> void:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = r
	sm.height = r * 2.0
	mi.mesh = sm
	mi.position.y = y
	mi.material_override = mat
	root.add_child(mi)
