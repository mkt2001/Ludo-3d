class_name GameController
extends Node3D
## Runs one match: one authoritative state (tokens[player][token] = progress), strict turn flow,
## all rules come from GameRules / AntiStackDiceManager. Animations never change state.

var hud: Hud
var board: Board3D
var dice3d: Dice3D
var cam: Camera3D
var theme: Dictionary
var players: Array = []
var is_ai := [false, false, false, false]
var tokens: Array = []
var nodes: Array = []
var cur := 0
var state := "roll"     # roll | pick | anim | over
var busy := false
var legal: Array = []
var rolled := 0
var asm := AntiStackDiceManager.new()
var rng := RandomNumberGenerator.new()
var kills := [0, 0, 0, 0]
var homes := [0, 0, 0, 0]
var gen := 0
var confetti: CPUParticles3D

func begin() -> void:
	rng.randomize()
	theme = Themes.get_theme(Settings.theme_idx)
	asm.mode = Settings.dice_mode
	asm.protect_opening = Settings.custom_opening
	asm.protect_track = Settings.custom_track
	asm.protect_home_lane = Settings.custom_lane
	match Settings.players_count:
		2: players = [0, 2]
		3: players = [0, 1, 2]
		_: players = [0, 1, 2, 3]
	for i in 4:
		is_ai[i] = Settings.game_mode == 0 and i != players[0]
		tokens.append([-1, -1, -1, -1])
	_build_scene()
	hud.roll_pressed.connect(do_roll)
	hud.pause_changed.connect(func(p): get_tree().paused = p)
	_refresh_scores()
	cur = 0
	begin_turn()

func _build_scene() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = theme.bg
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(1, 1, 1)
	env.ambient_light_energy = 0.6
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-62, -25, 0)
	sun.light_energy = 1.0
	sun.shadow_enabled = true
	add_child(sun)
	cam = Camera3D.new()
	cam.keep_aspect = Camera3D.KEEP_WIDTH
	cam.fov = 52
	cam.position = Vector3(0, 21, 7.5)
	add_child(cam)
	cam.look_at(Vector3(0, 0, 0.3))
	cam.current = true
	board = Board3D.new()
	add_child(board)
	board.build(theme)
	for i in 4:
		board.set_label(i, Settings.color_name(i, is_ai[i]), players.has(i))
	dice3d = Dice3D.new()
	add_child(dice3d)
	dice3d.build(theme)
	for pl in 4:
		nodes.append([])
		for i in 4:
			var n := _make_token(pl)
			n.position = BoardGeo.token_pos(pl, -1, i)
			n.visible = players.has(pl)
			add_child(n)
			nodes[pl].append(n)

func _make_token(pl: int) -> Node3D:
	var root := Node3D.new()
	var m := StandardMaterial3D.new()
	m.albedo_color = theme.p[pl]
	m.metallic = theme.metal
	m.roughness = clampf(theme.rough, 0.15, 0.8)
	if theme.glow:
		m.emission_enabled = true
		m.emission = theme.p[pl]
		m.emission_energy_multiplier = 0.5
	var shape: int = theme.shape
	if shape == 1:
		var d := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radial_segments = 4
		sm.rings = 2
		sm.radius = 0.32
		sm.height = 0.9
		d.mesh = sm
		d.position.y = 0.45
		d.rotation_degrees.y = 45
		d.material_override = m
		root.add_child(d)
	else:
		var b := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.bottom_radius = 0.3
		cm.top_radius = 0.16 if shape == 0 else 0.3
		cm.height = 0.4 if shape == 0 else 0.28
		b.mesh = cm
		b.position.y = cm.height / 2.0
		b.material_override = m
		root.add_child(b)
		var h := MeshInstance3D.new()
		var hm := SphereMesh.new()
		hm.radius = 0.2 if shape == 0 else 0.15
		hm.height = hm.radius * 2.0
		h.mesh = hm
		h.position.y = cm.height + hm.radius * 0.7
		h.material_override = m
		root.add_child(h)
	var ring := MeshInstance3D.new()
	ring.name = "ring"
	var rm := CylinderMesh.new()
	rm.top_radius = 0.5
	rm.bottom_radius = 0.5
	rm.height = 0.03
	ring.mesh = rm
	var rmat := StandardMaterial3D.new()
	rmat.albedo_color = Color("fff176")
	rmat.emission_enabled = true
	rmat.emission = Color("fff176")
	rmat.emission_energy_multiplier = 2.5
	ring.material_override = rmat
	ring.position.y = 0.03
	ring.visible = false
	root.add_child(ring)
	return root

func _wait(t: float) -> void:
	await get_tree().create_timer(t / Settings.speed, false).timeout

# ---------------------------------------------------------------- turn flow

func begin_turn() -> void:
	var my := gen
	state = "roll"
	busy = false
	var pl: int = players[cur]
	board.set_active(pl)
	dice3d.show_at(board.dice_spot(pl))
	AudioMgr.play("turn")
	hud.set_status(Settings.tx("turn", [Settings.color_name(pl, is_ai[pl])]), theme.p[pl])
	var info := asm.calculate(tokens[pl])
	hud.set_dice_info(info["available"], info["blocked"])
	_refresh_scores()
	hud.set_roll_enabled(not is_ai[pl])
	if is_ai[pl]:
		await _wait(0.9)
		if my != gen: return
		do_roll()

func next_turn() -> void:
	var my := gen
	busy = true
	hud.set_roll_enabled(false)
	board.clear_active()
	dice3d.hide_dice()
	await _wait(0.35)
	if my != gen: return
	cur = (cur + 1) % players.size()
	begin_turn()

func do_roll() -> void:
	if state != "roll" or busy:
		return
	busy = true
	var my := gen
	var pl: int = players[cur]
	hud.set_roll_enabled(false)
	var r := asm.roll(tokens[pl], rng)
	if r["no_valid_move"]:
		hud.banner(Settings.tx("no_move"), Color("ff8a80"))
		await _wait(1.0)
		if my != gen: return
		next_turn()
		return
	rolled = r["value"]
	hud.set_dice_info(r["available"], r["blocked"])
	if not r["blocked"].is_empty():
		hud.toast(Settings.tx("stack_block"))
	AudioMgr.play("dice_roll")
	await dice3d.roll_to(rolled, Settings.speed)
	if my != gen: return
	AudioMgr.play("dice_land")
	AudioMgr.vibrate(30)
	if rolled == 6:
		AudioMgr.play("six")
	legal = asm.legal_tokens(tokens[pl], rolled)
	if legal.is_empty():
		hud.banner(Settings.tx("no_move"), Color("ff8a80"))
		await _wait(1.0)
		if my != gen: return
		next_turn()
		return
	if legal.size() == 1:
		do_move(legal[0])
	elif is_ai[pl]:
		await _wait(0.5)
		if my != gen: return
		do_move(AIPlayer.choose(Settings.ai_level, tokens, pl, rolled, legal, rng))
	else:
		state = "pick"
		busy = false
		hud.set_status(Settings.tx("pick"), theme.p[pl])
		_highlight(true)

func _highlight(on: bool) -> void:
	var pl: int = players[cur]
	for i in 4:
		var ring: Node3D = nodes[pl][i].get_node("ring")
		ring.visible = on and legal.has(i)

func _unhandled_input(event: InputEvent) -> void:
	if state != "pick" or busy or get_tree().paused:
		return
	if not (event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT):
		return
	var pl: int = players[cur]
	var best := -1
	var best_d := 90.0
	for i in legal:
		var sp := cam.unproject_position(nodes[pl][i].global_position + Vector3(0, 0.3, 0))
		var d := sp.distance_to(event.position)
		if d < best_d:
			best_d = d
			best = i
	if best != -1:
		do_move(best)

func _hop(node: Node3D, to: Vector3, dur: float) -> void:
	var from := node.position
	var tw := node.create_tween()
	tw.tween_method(func(t: float): node.position = from.lerp(to, t) + Vector3(0, sin(t * PI) * 0.55, 0), 0.0, 1.0, dur / Settings.speed)
	await tw.finished

func do_move(idx: int) -> void:
	state = "anim"
	busy = true
	_highlight(false)
	var my := gen
	var pl: int = players[cur]
	var from: int = tokens[pl][idx]
	var dest := GameRules.destination(from, rolled)
	var node: Node3D = nodes[pl][idx]
	if from == GameRules.BASE:
		AudioMgr.play("jump")
		await _hop(node, BoardGeo.token_pos(pl, 0, idx), 0.35)
	else:
		for p in range(from + 1, dest + 1):
			AudioMgr.play("move", 0.7)
			await _hop(node, BoardGeo.token_pos(pl, p, idx), 0.17)
			if my != gen: return
	if my != gen: return
	var res := GameRules.apply_move(tokens, pl, idx, rolled)
	if not res["captured"].is_empty():
		AudioMgr.play("capture")
		AudioMgr.vibrate(150)
		AudioMgr.speak(Settings.tx("captured_voice"))
		hud.banner(Settings.tx("captured"), Color("ff5252"))
		_cam_punch()
		for c in res["captured"]:
			kills[pl] += 1
			var vn: Node3D = nodes[c[0]][c[1]]
			_hop(vn, BoardGeo.token_pos(c[0], -1, c[1]), 0.7)
		await _wait(0.5)
		AudioMgr.play("home")
		await _wait(0.5)
		if my != gen: return
	if res["finished"]:
		homes[pl] += 1
		AudioMgr.play("home")
	_layout()
	_refresh_scores()
	if GameRules.has_won(tokens[pl]):
		_win(pl)
		return
	if GameRules.grants_extra_turn(rolled, res):
		hud.toast(Settings.tx("six") if rolled == 6 else Settings.tx("bonus"))
		await _wait(0.4)
		if my != gen: return
		begin_turn()
	else:
		next_turn()

## Spread tokens that share a cell so they stay visible.
func _layout() -> void:
	var groups := {}
	for pl in players:
		for i in 4:
			var base := BoardGeo.token_pos(pl, tokens[pl][i], i)
			var key := Vector2i(roundi(base.x * 10), roundi(base.z * 10))
			if not groups.has(key):
				groups[key] = []
			groups[key].append([pl, i, base])
	for key in groups:
		var g: Array = groups[key]
		for k in g.size():
			var off := Vector3.ZERO
			if g.size() > 1:
				var a := TAU * k / g.size()
				off = Vector3(cos(a), 0, sin(a)) * 0.24
			var n: Node3D = nodes[g[k][0]][g[k][1]]
			n.create_tween().tween_property(n, "position", g[k][2] + off, 0.15)

func _cam_punch() -> void:
	var tw := cam.create_tween()
	var p := cam.position
	tw.tween_property(cam, "fov", 46.0, 0.12)
	tw.tween_property(cam, "position", p + Vector3(0.15, 0, 0), 0.04)
	tw.tween_property(cam, "position", p - Vector3(0.15, 0, 0), 0.04)
	tw.tween_property(cam, "position", p, 0.04)
	tw.tween_property(cam, "fov", 52.0, 0.35)

func _refresh_scores() -> void:
	var entries := []
	for pl in players:
		entries.append({"pl": pl, "name": Settings.color_name(pl, is_ai[pl]), "color": theme.p[pl], "home": homes[pl], "kills": kills[pl]})
	hud.set_scores(entries, players[cur])

func _win(pl: int) -> void:
	state = "over"
	busy = true
	board.clear_active()
	AudioMgr.play("win")
	var who := Settings.color_name(pl, is_ai[pl])
	AudioMgr.speak(Settings.tx("win_text", [who]))
	Settings.games += 1
	if not is_ai[pl]:
		Settings.wins += 1
		Settings.coins += 50
	else:
		Settings.coins += 5
	Settings.save_all()
	confetti = CPUParticles3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.12
	sm.height = 0.24
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	sm.material = mat
	confetti.mesh = sm
	confetti.amount = 220
	confetti.lifetime = 3.0
	confetti.one_shot = true
	confetti.explosiveness = 0.9
	confetti.direction = Vector3.UP
	confetti.spread = 70.0
	confetti.initial_velocity_min = 7.0
	confetti.initial_velocity_max = 12.0
	confetti.gravity = Vector3(0, -7, 0)
	var grad := Gradient.new()
	grad.colors = PackedColorArray([Color("ff5252"), Color("ffd24a"), Color("4caf50"), Color("42a5f5")])
	grad.offsets = PackedFloat32Array([0.0, 0.33, 0.66, 1.0])
	confetti.color_initial_ramp = grad
	confetti.position = Vector3(0, 1, 0)
	add_child(confetti)
	confetti.emitting = true
	hud.show_result(Settings.tx("win_text", [who]), theme.p[pl])
