class_name GameController
extends Node3D
## One match. Single authoritative state: tokens[player][token] = progress.
## Animations never change state. Dice is tapped (no text UI).

const CAM_FOV := 60.0

var hud: Hud
var board: Board3D
var dice3d: Dice3D
var cam: Camera3D
var theme: Dictionary
var players: Array = []
var is_ai := [false, false, false, false]
var tokens: Array = []
var nodes: Array = []
var cur := 0
var state := "roll"     # roll | pick | anim | over
var busy := false
var legal: Array = []
var rolled := 0
var asm := AntiStackDiceManager.new()
var rng := RandomNumberGenerator.new()
var kills := [0, 0, 0, 0]
var homes := [0, 0, 0, 0]
var gen := 0
var hl_tw := {}

func begin() -> void:
	rng.randomize()
	theme = Themes.get_theme(Settings.theme_idx)
	asm.mode = Settings.dice_mode
	asm.protect_opening = Settings.custom_opening
	asm.protect_track = Settings.custom_track
	asm.protect_home_lane = Settings.custom_lane
	match Settings.players_count:
		2: players = [0, 2]
		3: players = [0, 1, 2]
		_: players = [0, 1, 2, 3]
	for i in 4:
		is_ai[i] = Settings.game_mode == 0 and i != players[0]
		tokens.append([-1, -1, -1, -1])
	_build_scene()
	hud.pause_changed.connect(func(p): get_tree().paused = p)
	cur = 0
	begin_turn()

func _build_scene() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = (theme.bg as Color).darkened(0.2)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.85, 0.88, 1.0)
	env.ambient_light_energy = 0.42
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.adjustment_enabled = true
	env.adjustment_saturation = 1.2
	env.adjustment_contrast = 1.08
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-58, -28, 0)
	sun.light_energy = 1.25
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 45.0
	add_child(sun)
	var fill := OmniLight3D.new()
	fill.position = Vector3(0, 12, 4)
	fill.omni_range = 40.0
	fill.light_energy = 0.5
	add_child(fill)
	cam = Camera3D.new()
	cam.keep_aspect = Camera3D.KEEP_WIDTH
	cam.fov = CAM_FOV
	cam.position = Vector3(0, 16.5, 10.0)
	add_child(cam)
	cam.look_at(Vector3(0, 0, 0.5))
	cam.current = true
	board = Board3D.new()
	add_child(board)
	board.build(theme)
	dice3d = Dice3D.new()
	add_child(dice3d)
	dice3d.build(theme)
	for pl in 4:
		nodes.append([])
		for i in 4:
			var n := TokenFactory.make(theme, pl)
			n.position = BoardGeo.token_pos(pl, -1, i)
			n.visible = players.has(pl)
			add_child(n)
			nodes[pl].append(n)

func _wait(t: float) -> void:
	await get_tree().create_timer(t / Settings.speed, false).timeout

# ---------------------------------------------------------------- turn flow

func begin_turn() -> void:
	var my := gen
	state = "roll"
	busy = false
	var pl: int = players[cur]
	board.set_active(pl)
	dice3d.show_at(board.dice_spot(pl))
	hud.set_turn(theme.p[pl])
	AudioMgr.play("turn")
	if is_ai[pl]:
		await _wait(0.9)
		if my != gen: return
		do_roll()
	else:
		await _wait(0.35)
		if my != gen: return
		if state == "roll":
			dice3d.start_idle()

func next_turn() -> void:
	var my := gen
	busy = true
	board.clear_active()
	dice3d.hide_dice()
	await _wait(0.35)
	if my != gen: return
	cur = (cur + 1) % players.size()
	begin_turn()

func do_roll() -> void:
	if state != "roll" or busy:
		return
	busy = true
	var my := gen
	var pl: int = players[cur]
	var r := asm.roll(tokens[pl], rng)
	if r["no_valid_move"]:
		dice3d.shake()
		await _wait(0.9)
		if my != gen: return
		next_turn()
		return
	rolled = r["value"]
	AudioMgr.play("dice_roll")
	await dice3d.roll_to(rolled, Settings.speed)
	if my != gen: return
	AudioMgr.play("dice_land")
	AudioMgr.vibrate(30)
	if rolled == 6:
		AudioMgr.play("six")
	legal = _dedupe(asm.legal_tokens(tokens[pl], rolled), pl)
	if legal.is_empty():
		dice3d.shake()
		await _wait(0.9)
		if my != gen: return
		next_turn()
		return
	if legal.size() == 1:
		await _wait(0.25)
		if my != gen: return
		do_move(legal[0])
	elif is_ai[pl]:
		await _wait(0.5)
		if my != gen: return
		do_move(AIPlayer.choose(Settings.ai_level, tokens, pl, rolled, legal, rng))
	else:
		state = "pick"
		busy = false
		_highlight(true)

## Tokens standing on the same spot (e.g. several still in base) are one choice.
func _dedupe(list: Array, pl: int) -> Array:
	var seen := {}
	var out := []
	for i in list:
		var p: int = tokens[pl][i]
		if not seen.has(p):
			seen[p] = true
			out.append(i)
	return out

func _highlight(on: bool) -> void:
	var pl: int = players[cur]
	for k in hl_tw.keys():
		if hl_tw[k]:
			hl_tw[k].kill()
	hl_tw.clear()
	for i in 4:
		var n: Node3D = nodes[pl][i]
		var ring: Node3D = n.get_node("ring")
		var lit := on and legal.has(i)
		ring.visible = lit
		n.scale = Vector3.ONE
		if lit:
			var tw := n.create_tween().set_loops()
			tw.tween_property(n, "scale", Vector3.ONE * 1.2, 0.35).set_trans(Tween.TRANS_SINE)
			tw.tween_property(n, "scale", Vector3.ONE, 0.35).set_trans(Tween.TRANS_SINE)
			hl_tw[i] = tw

func _unhandled_input(event: InputEvent) -> void:
	if busy or get_tree().paused:
		return
	if not (event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT):
		return
	var pl: int = players[cur]
	if state == "roll" and not is_ai[pl]:
		var sp := cam.unproject_position(dice3d.global_position)
		if sp.distance_to(event.position) < 230.0:
			do_roll()
	elif state == "pick":
		var best := -1
		var best_d := 110.0
		for i in legal:
			var tp := cam.unproject_position(nodes[pl][i].global_position + Vector3(0, 0.4, 0))
			var d := tp.distance_to(event.position)
			if d < best_d:
				best_d = d
				best = i
		if best != -1:
			do_move(best)

func _hop(node: Node3D, to: Vector3, dur: float) -> void:
	var from := node.position
	var tw := node.create_tween()
	tw.tween_method(func(t: float): node.position = from.lerp(to, t) + Vector3(0, sin(t * PI) * 0.7, 0), 0.0, 1.0, dur / Settings.speed)
	await tw.finished

func do_move(idx: int) -> void:
	state = "anim"
	busy = true
	_highlight(false)
	var my := gen
	var pl: int = players[cur]
	var from: int = tokens[pl][idx]
	var dest := GameRules.destination(from, rolled)
	var node: Node3D = nodes[pl][idx]
	if from == GameRules.BASE:
		AudioMgr.play("jump")
		await _hop(node, BoardGeo.token_pos(pl, 0, idx), 0.4)
	else:
		for p in range(from + 1, dest + 1):
			AudioMgr.play("move", 0.7)
			await _hop(node, BoardGeo.token_pos(pl, p, idx), 0.17)
			if my != gen: return
	if my != gen: return
	var res := GameRules.apply_move(tokens, pl, idx, rolled)
	if not res["captured"].is_empty():
		AudioMgr.play("capture")
		AudioMgr.vibrate(150)
		AudioMgr.speak(Settings.tx("captured_voice"))
		_burst(node.position, Color("ff5252"), 60)
		_cam_punch()
		for c in res["captured"]:
			kills[pl] += 1
			var vn: Node3D = nodes[c[0]][c[1]]
			_burst(vn.position, theme.p[c[0]], 30)
			_hop(vn, BoardGeo.token_pos(c[0], -1, c[1]), 0.7)
		await _wait(0.55)
		AudioMgr.play("home")
		await _wait(0.5)
		if my != gen: return
	if res["finished"]:
		homes[pl] += 1
		AudioMgr.play("home")
		_burst(node.position, Color("ffd24a"), 50)
	_layout()
	if GameRules.has_won(tokens[pl]):
		_win(pl)
		return
	if GameRules.grants_extra_turn(rolled, res):
		await _wait(0.4)
		if my != gen: return
		begin_turn()
	else:
		next_turn()

## Spread tokens that share a cell so every one stays visible.
func _layout() -> void:
	var groups := {}
	for pl in players:
		for i in 4:
			var base := BoardGeo.token_pos(pl, tokens[pl][i], i)
			var key := Vector2i(roundi(base.x * 10), roundi(base.z * 10))
			if not groups.has(key):
				groups[key] = []
			groups[key].append([pl, i, base])
	for key in groups:
		var g: Array = groups[key]
		for k in g.size():
			var off := Vector3.ZERO
			if g.size() > 1:
				var a := TAU * k / g.size()
				off = Vector3(cos(a), 0, sin(a)) * 0.26
			var n: Node3D = nodes[g[k][0]][g[k][1]]
			n.create_tween().tween_property(n, "position", g[k][2] + off, 0.15)

func _cam_punch() -> void:
	var tw := cam.create_tween()
	var p := cam.position
	tw.tween_property(cam, "fov", CAM_FOV - 6.0, 0.12)
	tw.tween_property(cam, "position", p + Vector3(0.18, 0, 0), 0.04)
	tw.tween_property(cam, "position", p - Vector3(0.18, 0, 0), 0.04)
	tw.tween_property(cam, "position", p, 0.04)
	tw.tween_property(cam, "fov", CAM_FOV, 0.35)

func _burst(pos: Vector3, col: Color, amount := 36) -> void:
	var p := CPUParticles3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.09
	sm.height = 0.18
	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	mat.emission_enabled = true
	mat.emission = col
	sm.material = mat
	p.mesh = sm
	p.amount = amount
	p.lifetime = 0.8
	p.one_shot = true
	p.explosiveness = 1.0
	p.direction = Vector3.UP
	p.spread = 90.0
	p.initial_velocity_min = 3.0
	p.initial_velocity_max = 6.5
	p.gravity = Vector3(0, -12, 0)
	p.position = pos + Vector3(0, 0.3, 0)
	add_child(p)
	p.emitting = true
	await get_tree().create_timer(1.5, false).timeout
	if is_instance_valid(p):
		p.queue_free()

func _win(pl: int) -> void:
	state = "over"
	busy = true
	board.clear_active()
	AudioMgr.play("win")
	AudioMgr.speak(Settings.tx("win_text", [Settings.color_name(pl, is_ai[pl])]))
	Settings.games += 1
	if not is_ai[pl]:
		Settings.wins += 1
		Settings.coins += 50
	else:
		Settings.coins += 5
	Settings.save_all()
	var confetti := CPUParticles3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.12
	sm.height = 0.24
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	sm.material = mat
	confetti.mesh = sm
	confetti.amount = 220
	confetti.lifetime = 3.0
	confetti.one_shot = true
	confetti.explosiveness = 0.9
	confetti.direction = Vector3.UP
	confetti.spread = 70.0
	confetti.initial_velocity_min = 7.0
	confetti.initial_velocity_max = 12.0
	confetti.gravity = Vector3(0, -7, 0)
	var grad := Gradient.new()
	grad.colors = PackedColorArray([Color("ff5252"), Color("ffd24a"), Color("4caf50"), Color("42a5f5")])
	grad.offsets = PackedFloat32Array([0.0, 0.33, 0.66, 1.0])
	confetti.color_initial_ramp = grad
	confetti.position = Vector3(0, 1, 0)
	add_child(confetti)
	confetti.emitting = true
	hud.show_result(theme.p[pl])
