class_name Dice3D
extends Node3D
## Real 3D cube with pips. Rolls by tumbling and ends with the logical value on top,
## so the picture always matches the game value.

const NORMALS := {1: Vector3.UP, 6: Vector3.DOWN, 2: Vector3(0, 0, 1), 5: Vector3(0, 0, -1), 3: Vector3(1, 0, 0), 4: Vector3(-1, 0, 0)}
const PIPS := {
	1: [[0, 0]], 2: [[-1, -1], [1, 1]], 3: [[-1, -1], [0, 0], [1, 1]],
	4: [[-1, -1], [1, -1], [-1, 1], [1, 1]], 5: [[-1, -1], [1, -1], [0, 0], [-1, 1], [1, 1]],
	6: [[-1, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [1, 1]],
}

func build(theme: Dictionary) -> void:
	var cube := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3.ONE * 0.9
	cube.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = theme.dice
	m.metallic = theme.metal
	m.roughness = clampf(theme.rough, 0.1, 0.7)
	cube.material_override = m
	add_child(cube)
	var pm := StandardMaterial3D.new()
	pm.albedo_color = theme.pip
	if theme.glow:
		pm.emission_enabled = true
		pm.emission = theme.pip
	var sm := SphereMesh.new()
	sm.radius = 0.07
	sm.height = 0.14
	for v in NORMALS:
		var n: Vector3 = NORMALS[v]
		var u := n.cross(Vector3.UP)
		if u.length() < 0.1:
			u = Vector3.RIGHT
		u = u.normalized()
		var w := n.cross(u)
		for pip in PIPS[v]:
			var mi := MeshInstance3D.new()
			mi.mesh = sm
			mi.material_override = pm
			mi.position = n * 0.45 + u * pip[0] * 0.22 + w * pip[1] * 0.22
			add_child(mi)
	visible = false
	scale = Vector3.ZERO

func show_at(spot: Vector3) -> void:
	position = spot + Vector3(0, 0.5, 0)
	quaternion = _target_q(randi_range(1, 6))
	visible = true
	scale = Vector3.ZERO
	create_tween().tween_property(self, "scale", Vector3.ONE, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

func hide_dice() -> void:
	var tw := create_tween()
	tw.tween_property(self, "scale", Vector3.ZERO, 0.2)
	await tw.finished
	visible = false

func _target_q(v: int) -> Quaternion:
	var n: Vector3 = NORMALS[v]
	var align := Quaternion.IDENTITY
	if n.is_equal_approx(Vector3.DOWN):
		align = Quaternion(Vector3.RIGHT, PI)
	elif not n.is_equal_approx(Vector3.UP):
		align = Quaternion(n, Vector3.UP)
	return Quaternion(Vector3.UP, randf() * TAU) * align

func roll_to(v: int, speed := 1.0) -> void:
	var base_y := position.y
	var tw := create_tween()
	for i in 6:
		var axis := Vector3(randf() - 0.5, randf() - 0.5, randf() - 0.5).normalized()
		tw.tween_property(self, "quaternion", Quaternion(axis, randf() * TAU), 0.11 / speed)
	tw.tween_property(self, "quaternion", _target_q(v), 0.14 / speed)
	var tb := create_tween()
	for i in 3:
		tb.tween_property(self, "position:y", base_y + 1.3 / (i + 1), 0.16 / speed).set_ease(Tween.EASE_OUT)
		tb.tween_property(self, "position:y", base_y, 0.14 / speed).set_ease(Tween.EASE_IN)
	await tw.finished
	if tb.is_running():
		await tb.finished
