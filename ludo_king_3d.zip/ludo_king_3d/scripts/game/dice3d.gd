class_name Dice3D
extends Node3D
## Big readable 3D dice. Tumbles, bounces, then settles with the logical value on top,
## tilted toward the camera and upright, so the pips are always clear.

const SIZE := 1.5
const TILT := 30.0
const NORMALS := {1: Vector3.UP, 6: Vector3.DOWN, 2: Vector3(0, 0, 1), 5: Vector3(0, 0, -1), 3: Vector3(1, 0, 0), 4: Vector3(-1, 0, 0)}
const PIPS := {
	1: [[0, 0]], 2: [[-1, -1], [1, 1]], 3: [[-1, -1], [0, 0], [1, 1]],
	4: [[-1, -1], [1, -1], [-1, 1], [1, 1]], 5: [[-1, -1], [1, -1], [0, 0], [-1, 1], [1, 1]],
	6: [[-1, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [1, 1]],
}

var base_scale := 1.0
var rest_y := 0.0
var idle_tw: Tween

static func _face_u(n: Vector3) -> Vector3:
	var u := n.cross(Vector3.UP)
	if u.length() < 0.1:
		u = Vector3.RIGHT
	return u.normalized()

static func _arc_q(n: Vector3) -> Quaternion:   # rotation UP -> n
	if n.is_equal_approx(Vector3.UP):
		return Quaternion.IDENTITY
	if n.is_equal_approx(Vector3.DOWN):
		return Quaternion(Vector3.RIGHT, PI)
	return Quaternion(Vector3.UP, n)

func build(theme: Dictionary) -> void:
	var cube := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3.ONE * SIZE
	cube.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = theme.dice
	m.metallic = clampf(theme.metal, 0.0, 0.4)
	m.roughness = clampf(theme.rough, 0.2, 0.55)
	if theme.glow:
		m.emission_enabled = true
		m.emission = theme.dice
		m.emission_energy_multiplier = 0.3
	cube.material_override = m
	add_child(cube)
	var pm := StandardMaterial3D.new()
	pm.albedo_color = theme.pip
	pm.roughness = 0.3
	if theme.glow:
		pm.emission_enabled = true
		pm.emission = theme.pip
		pm.emission_energy_multiplier = 1.5
	var cyl := CylinderMesh.new()
	cyl.top_radius = SIZE * 0.095
	cyl.bottom_radius = SIZE * 0.095
	cyl.height = 0.035
	for v in NORMALS:
		var n: Vector3 = NORMALS[v]
		var u := _face_u(n)
		var w := n.cross(u)
		for pip in PIPS[v]:
			var mi := MeshInstance3D.new()
			mi.mesh = cyl
			mi.material_override = pm
			mi.quaternion = _arc_q(n)
			mi.position = n * (SIZE * 0.5 + 0.004) + u * pip[0] * SIZE * 0.24 + w * pip[1] * SIZE * 0.24
			add_child(mi)
	visible = false
	scale = Vector3.ZERO

func show_at(spot: Vector3) -> void:
	stop_idle()
	base_scale = 1.3 if spot.z < 0.0 else 1.0
	rest_y = spot.y + SIZE * 0.5 * base_scale
	position = Vector3(spot.x, rest_y, spot.z)
	quaternion = _target_q(randi_range(1, 6))
	visible = true
	scale = Vector3.ZERO
	create_tween().tween_property(self, "scale", Vector3.ONE * base_scale, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

func hide_dice() -> void:
	stop_idle()
	var tw := create_tween()
	tw.tween_property(self, "scale", Vector3.ZERO, 0.2)
	await tw.finished
	visible = false

func start_idle() -> void:
	stop_idle()
	idle_tw = create_tween().set_loops()
	idle_tw.tween_property(self, "position:y", rest_y + 0.4, 0.55).set_trans(Tween.TRANS_SINE)
	idle_tw.tween_property(self, "position:y", rest_y, 0.55).set_trans(Tween.TRANS_SINE)

func stop_idle() -> void:
	if idle_tw:
		idle_tw.kill()
		idle_tw = null
	if rest_y != 0.0:
		position.y = rest_y

func shake() -> void:
	var x0 := position.x
	var tw := create_tween()
	for i in 3:
		tw.tween_property(self, "position:x", x0 + 0.25, 0.05)
		tw.tween_property(self, "position:x", x0 - 0.25, 0.05)
	tw.tween_property(self, "position:x", x0, 0.05)

func _target_q(v: int) -> Quaternion:
	var n: Vector3 = NORMALS[v]
	var al := _arc_q(n).inverse()                 # rotation n -> UP
	var u2: Vector3 = al * _face_u(n)
	var yaw := u2.signed_angle_to(Vector3.RIGHT, Vector3.UP)
	return Quaternion(Vector3.RIGHT, deg_to_rad(TILT)) * Quaternion(Vector3.UP, yaw) * al

func roll_to(v: int, speed := 1.0) -> void:
	stop_idle()
	var tw := create_tween()
	for i in 7:
		var axis := Vector3(randf() - 0.5, randf() - 0.5, randf() - 0.5).normalized()
		tw.tween_property(self, "quaternion", Quaternion(axis, randf() * TAU), 0.1 / speed)
	tw.tween_property(self, "quaternion", _target_q(v), 0.18 / speed)
	var tb := create_tween()
	var hs := [3.0, 1.6, 0.7]
	for h in hs:
		tb.tween_property(self, "position:y", rest_y + h, 0.2 / speed).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)
		tb.tween_property(self, "position:y", rest_y, 0.18 / speed).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUAD)
	await tw.finished
	if tb.is_running():
		await tb.finished
	var pop := create_tween()
	pop.tween_property(self, "scale", Vector3.ONE * base_scale * 1.18, 0.08)
	pop.tween_property(self, "scale", Vector3.ONE * base_scale, 0.12)
