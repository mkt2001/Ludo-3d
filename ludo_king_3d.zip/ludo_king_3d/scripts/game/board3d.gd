class_name Board3D
extends Node3D
## Builds the 3D board from primitives, coloured by the selected theme.

const SPOT_X := [-4.5, 4.5, 4.5, -4.5]
const SPOT_Z := [-8.9, -8.9, 8.9, 8.9]

var th: Dictionary
var glow_nodes: Array = []
var glow_mat: StandardMaterial3D
var labels: Array = []
var pulse: Tween

func _mat(c: Color, metal := 0.1, rough := 0.6, glow := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.metallic = metal
	m.roughness = rough
	if glow > 0.0:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = glow
	return m

func _box(pos: Vector3, size: Vector3, mat: Material, parent: Node = null) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	(parent if parent else self).add_child(mi)
	return mi

func _disc(pos: Vector3, r: float, h: float, mat: Material) -> void:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = r
	cm.bottom_radius = r
	cm.height = h
	mi.mesh = cm
	mi.material_override = mat
	mi.position = pos
	add_child(mi)

func build(theme: Dictionary) -> void:
	th = theme
	var glow_c := 0.4 if th.glow else 0.0
	_box(Vector3(0, -0.35, 0), Vector3(16.4, 0.7, 16.4), _mat(th.frame, th.metal, th.rough))
	_box(Vector3(0, 0, 0), Vector3(15, 0.1, 15), _mat(th.board, th.metal * 0.5, th.rough))
	var gold := _mat(Color("ffd24a"), 0.8, 0.25, 0.5)
	glow_mat = _mat(Color.WHITE, 0.0, 0.5, 2.0)
	for pl in 4:
		var bc: Vector2 = BoardGeo.BASE_C[pl]
		var c3 := Vector3(bc.x - 7.5, 0, bc.y - 7.5)
		_box(c3 + Vector3(0, 0.06, 0), Vector3(6, 0.12, 6), _mat(th.p[pl], th.metal, th.rough, glow_c))
		_box(c3 + Vector3(0, 0.13, 0), Vector3(4, 0.04, 4), _mat(th.cell, 0.1, 0.5))
		var dark: Color = (th.p[pl] as Color).darkened(0.25)
		for s in 4:
			var sp := BoardGeo.token_pos(pl, -1, s)
			_disc(Vector3(sp.x, 0.17, sp.z), 0.4, 0.03, _mat(dark, th.metal, th.rough))
		var g := Node3D.new()
		g.position = c3
		add_child(g)
		_box(Vector3(0, 0.14, -3.0), Vector3(6.2, 0.1, 0.16), glow_mat, g)
		_box(Vector3(0, 0.14, 3.0), Vector3(6.2, 0.1, 0.16), glow_mat, g)
		_box(Vector3(-3.0, 0.14, 0), Vector3(0.16, 0.1, 6.2), glow_mat, g)
		_box(Vector3(3.0, 0.14, 0), Vector3(0.16, 0.1, 6.2), glow_mat, g)
		g.visible = false
		glow_nodes.append(g)
	var cell_m := _mat(th.cell, 0.1, 0.5, glow_c)
	var tr := BoardGeo.track()
	for i in 52:
		var c: Vector2i = tr[i]
		var m: Material = cell_m
		if i % 13 == 0:
			m = _mat(th.p[i / 13], th.metal, th.rough, glow_c)
		_box(Vector3(c.x - 7, 0.1, c.y - 7), Vector3(0.94, 0.1, 0.94), m)
		if BoardGeo.SAFE.has(i):
			_disc(Vector3(c.x - 7, 0.17, c.y - 7), 0.27, 0.03, gold)
	for pl in 4:
		for k in 5:
			var lc := BoardGeo.lane_cell(pl, k)
			_box(Vector3(lc.x - 7, 0.1, lc.y - 7), Vector3(0.94, 0.1, 0.94), _mat(th.p[pl], th.metal, th.rough, glow_c))
		var f: Vector3 = BoardGeo.FIN[pl]
		_box(Vector3(f.x, 0.1, f.z), Vector3(0.94, 0.12, 0.94), _mat((th.p[pl] as Color).lightened(0.15), th.metal, th.rough, 0.3))
	_box(Vector3(0, 0.1, 0), Vector3(0.94, 0.12, 0.94), gold)
	for pl in 4:
		var lb := Label3D.new()
		lb.rotation_degrees = Vector3(-90, 0, 0)
		lb.pixel_size = 0.016
		lb.font_size = 64
		lb.outline_size = 12
		lb.modulate = th.p[pl]
		lb.position = Vector3(SPOT_X[pl], 0.05, SPOT_Z[pl] + (-1.25 if SPOT_Z[pl] < 0 else 1.25))
		add_child(lb)
		labels.append(lb)

func dice_spot(pl: int) -> Vector3:
	return Vector3(SPOT_X[pl], 0.0, SPOT_Z[pl])

func set_label(pl: int, text: String, visible_: bool) -> void:
	labels[pl].text = text
	labels[pl].visible = visible_

## Glowing border + dice only for the active player's section.
func set_active(pl: int) -> void:
	for i in 4:
		glow_nodes[i].visible = (i == pl)
	if pulse:
		pulse.kill()
	pulse = create_tween().set_loops()
	pulse.tween_property(glow_mat, "emission_energy_multiplier", 0.6, 0.6)
	pulse.tween_property(glow_mat, "emission_energy_multiplier", 2.5, 0.6)

func clear_active() -> void:
	for g in glow_nodes:
		g.visible = false
