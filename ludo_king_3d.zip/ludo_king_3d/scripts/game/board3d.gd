class_name Board3D
extends Node3D
## Raised 3D board with rim, relief tiles, table, soft glow pads for the active player's dice.

const SPOT_X := [-4.2, 4.2, 4.2, -4.2]
const SPOT_Z := [-10.2, -10.2, 10.2, 10.2]
const GROUND_Y := -0.7

var th: Dictionary
var glow_nodes: Array = []
var glow_mat: StandardMaterial3D
var pads: Array = []
var pulse: Tween

static func dull(c: Color, sat := 0.5, val := 0.7) -> Color:
	return Color.from_hsv(c.h, c.s * sat, c.v * val)

func _mat(c: Color, metal := 0.1, rough := 0.6, glow := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.metallic = metal
	m.roughness = rough
	if glow > 0.0:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = glow
	return m

func _box(pos: Vector3, size: Vector3, mat: Material, parent: Node = null) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	(parent if parent else self).add_child(mi)
	return mi

func _disc(pos: Vector3, r: float, h: float, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = r
	cm.bottom_radius = r
	cm.height = h
	mi.mesh = cm
	mi.material_override = mat
	mi.position = pos
	add_child(mi)
	return mi

func build(theme: Dictionary) -> void:
	th = theme
	var glow_c := 0.0   # board stays calm; only tokens glow
	# table
	var ground := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(600, 600)
	ground.mesh = pm
	ground.material_override = _mat((th.bg as Color).darkened(0.25), 0.0, 0.95)
	ground.position.y = GROUND_Y
	add_child(ground)
	# frame + rim
	var frame_m := _mat(th.frame, th.metal, th.rough)
	_box(Vector3(0, -0.35, 0), Vector3(16.8, 0.7, 16.8), frame_m)
	var rim_m := _mat((th.frame as Color).lightened(0.12), clampf(th.metal + 0.2, 0.0, 0.9), 0.3)
	_box(Vector3(0, 0.12, -8.25), Vector3(16.8, 0.3, 0.35), rim_m)
	_box(Vector3(0, 0.12, 8.25), Vector3(16.8, 0.3, 0.35), rim_m)
	_box(Vector3(-8.25, 0.12, 0), Vector3(0.35, 0.3, 16.8), rim_m)
	_box(Vector3(8.25, 0.12, 0), Vector3(0.35, 0.3, 16.8), rim_m)
	_box(Vector3(0, 0, 0), Vector3(15.2, 0.1, 15.2), _mat(th.board, th.metal * 0.5, th.rough))
	var cellc := Color.from_hsv((th.cell as Color).h, (th.cell as Color).s * 0.7, (th.cell as Color).v * 0.85)
	var gold := _mat(Color("d9b44a"), 0.6, 0.35, 0.15)
	glow_mat = _mat(Color.WHITE, 0.0, 0.5, 2.0)
	for pl in 4:
		var bc: Vector2 = BoardGeo.BASE_C[pl]
		var c3 := Vector3(bc.x - 7.5, 0, bc.y - 7.5)
		var pc: Color = dull(th.p[pl])
		_box(c3 + Vector3(0, 0.1, 0), Vector3(6, 0.2, 6), _mat(pc, th.metal, th.rough, glow_c))
		_box(c3 + Vector3(0, 0.22, 0), Vector3(4, 0.04, 4), _mat(cellc, 0.1, 0.45))
		for s in 4:
			var sp := BoardGeo.token_pos(pl, -1, s)
			_disc(Vector3(sp.x, 0.245, sp.z), 0.46, 0.03, _mat(pc.darkened(0.2), th.metal, th.rough))
			_disc(Vector3(sp.x, 0.262, sp.z), 0.34, 0.02, _mat(pc.lightened(0.18), th.metal, th.rough))
		var g := Node3D.new()
		g.position = c3
		add_child(g)
		_box(Vector3(0, 0.23, -3.0), Vector3(6.2, 0.1, 0.16), glow_mat, g)
		_box(Vector3(0, 0.23, 3.0), Vector3(6.2, 0.1, 0.16), glow_mat, g)
		_box(Vector3(-3.0, 0.23, 0), Vector3(0.16, 0.1, 6.2), glow_mat, g)
		_box(Vector3(3.0, 0.23, 0), Vector3(0.16, 0.1, 6.2), glow_mat, g)
		g.visible = false
		glow_nodes.append(g)
	var cell_m := _mat(cellc, 0.1, 0.5)
	var tr := BoardGeo.track()
	for i in 52:
		var c: Vector2i = tr[i]
		var m: Material = cell_m
		if i % 13 == 0:
			m = _mat(dull(th.p[i / 13]), th.metal, th.rough)
		_box(Vector3(c.x - 7, 0.1, c.y - 7), Vector3(0.92, 0.16, 0.92), m)
		if BoardGeo.SAFE.has(i):
			_disc(Vector3(c.x - 7, 0.185, c.y - 7), 0.28, 0.03, gold)
	for pl in 4:
		for k in 5:
			var lc := BoardGeo.lane_cell(pl, k)
			_box(Vector3(lc.x - 7, 0.1, lc.y - 7), Vector3(0.92, 0.16, 0.92), _mat(dull(th.p[pl]), th.metal, th.rough))
		var f: Vector3 = BoardGeo.FIN[pl]
		_box(Vector3(f.x, 0.1, f.z), Vector3(0.96, 0.18, 0.96), _mat(dull(th.p[pl]).lightened(0.12), th.metal, th.rough))
	_box(Vector3(0, 0.1, 0), Vector3(0.96, 0.2, 0.96), gold)
	# dice pads (always visible dark base, glowing when active)
	for pl in 4:
		var sx: float = SPOT_X[pl]
		var sz: float = SPOT_Z[pl]
		_disc(Vector3(sx, GROUND_Y + 0.03, sz), 1.45, 0.06, _mat(dull(th.p[pl], 0.6, 0.45), 0.2, 0.6))
		var pad := _disc(Vector3(sx, GROUND_Y + 0.07, sz), 1.3, 0.03, _mat(th.p[pl], 0.0, 0.4, 1.6))
		pad.visible = false
		pads.append(pad)

func dice_spot(pl: int) -> Vector3:
	return Vector3(SPOT_X[pl], GROUND_Y, SPOT_Z[pl])

func set_active(pl: int) -> void:
	for i in 4:
		glow_nodes[i].visible = (i == pl)
		pads[i].visible = (i == pl)
	if pulse:
		pulse.kill()
	pulse = create_tween().set_loops()
	pulse.tween_property(glow_mat, "emission_energy_multiplier", 0.6, 0.6)
	pulse.tween_property(glow_mat, "emission_energy_multiplier", 2.6, 0.6)

func clear_active() -> void:
	for i in 4:
		glow_nodes[i].visible = false
		pads[i].visible = false
