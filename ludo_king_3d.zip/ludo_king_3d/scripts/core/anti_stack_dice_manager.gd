class_name AntiStackDiceManager
extends RefCounted
## Decides which dice values may be rolled. Same-player stacking only; opponents never matter.

enum Mode { CLASSIC, ANTI_STACK, CUSTOM }

var mode: Mode = Mode.ANTI_STACK
# CUSTOM mode switches
var protect_opening := true
var protect_track := true
var protect_home_lane := true

func _protects(dest: int, from: int) -> bool:
	match mode:
		Mode.CLASSIC: return false
		Mode.ANTI_STACK: return true
	if from == GameRules.BASE: return protect_opening
	if GameRules.is_in_home_lane(dest): return protect_home_lane
	return protect_track

## True if moving token idx to dest lands on another token of the same player.
## Finished (56) is never a stack: many tokens may rest at home.
func would_stack(own: Array, idx: int, dest: int) -> bool:
	if dest == GameRules.FINISHED or not _protects(dest, own[idx]):
		return false
	for j in own.size():
		if j != idx and own[j] == dest:
			return true
	return false

## Token indices that can legally move with this dice (rules + anti-stack).
func legal_tokens(own: Array, dice: int) -> Array:
	var out := []
	for i in own.size():
		var dest := GameRules.destination(own[i], dice)
		if dest != GameRules.INVALID and not would_stack(own, i, dest):
			out.append(i)
	return out

## Block a value ONLY when some token could move (by normal rules) but every
## such move would stack. If nobody can move for other reasons, it stays available
## and the normal "no move, pass turn" rule applies.
func is_blocked(own: Array, dice: int) -> bool:
	var could_move := 0
	for i in own.size():
		var dest := GameRules.destination(own[i], dice)
		if dest == GameRules.INVALID:
			continue
		could_move += 1
		if not would_stack(own, i, dest):
			return false
	return could_move > 0

func calculate(own: Array) -> Dictionary:
	var available := []
	var blocked := []
	for d in range(1, 7):
		if is_blocked(own, d): blocked.append(d)
		else: available.append(d)
	return {"available": available, "blocked": blocked}

## Single authoritative roll: value is drawn from the available set only.
## Never draws then replaces. Run this on the server for online matches.
func roll(own: Array, rng: RandomNumberGenerator) -> Dictionary:
	var info := calculate(own)
	if info["available"].is_empty():
		return {"value": 0, "no_valid_move": true, "blocked": info["blocked"], "available": []}
	var v: int = info["available"][rng.randi_range(0, info["available"].size() - 1)]
	return {"value": v, "no_valid_move": false, "blocked": info["blocked"], "available": info["available"]}
