extends Node
## Autoload "Settings": saved options, profile stats, Hindi/English strings.

const SAVE_PATH := "user://settings.cfg"
const KEYS := ["lang", "theme_idx", "dice_mode", "custom_opening", "custom_track", "custom_lane",
	"players_count", "ai_level", "game_mode", "master", "music", "sfx", "music_on", "sfx_on",
	"vibration", "speed", "coins", "wins", "games"]

var lang := "en"
var theme_idx := 0
var dice_mode := 1          # 0 classic, 1 anti-stack, 2 custom
var custom_opening := true
var custom_track := true
var custom_lane := true
var players_count := 2
var ai_level := 1           # 0 easy, 1 medium, 2 expert
var game_mode := 0          # 0 vs computer, 1 pass and play
var master := 0.9
var music := 0.45
var sfx := 1.0
var music_on := true
var sfx_on := true
var vibration := true
var speed := 1.0
var coins := 0
var wins := 0
var games := 0

const S := {
	"sub": ["GRAND MASTER EDITION", "ग्रैंड मास्टर एडिशन"],
	"play_cpu": ["Play vs Computer", "कंप्यूटर के साथ खेलें"],
	"pass_play": ["Pass & Play (friends)", "दोस्तों के साथ खेलें"],
	"settings": ["Settings", "सेटिंग्स"],
	"online": ["Online (coming soon)", "ऑनलाइन (जल्द आ रहा है)"],
	"tourney": ["Tournament (coming soon)", "टूर्नामेंट (जल्द आ रहा है)"],
	"back": ["Back", "वापस"],
	"players": ["Players", "खिलाड़ी"],
	"difficulty": ["Computer level", "कंप्यूटर स्तर"],
	"easy": ["Easy", "आसान"], "medium": ["Medium", "मध्यम"], "expert": ["Expert", "एक्सपर्ट"],
	"dice_mode": ["Dice mode", "पासा मोड"],
	"m_classic": ["Classic Random", "क्लासिक रैंडम"],
	"m_anti": ["Anti-Stack", "एंटी-स्टैक"],
	"m_custom": ["Custom", "कस्टम"],
	"theme": ["Theme", "थीम"],
	"language": ["Language", "भाषा"],
	"music": ["Music", "संगीत"], "sound": ["Sound effects", "ध्वनि प्रभाव"],
	"vibration": ["Vibration", "वाइब्रेशन"],
	"speed": ["Game speed", "गेम स्पीड"],
	"slow": ["Slow", "धीमा"], "normal": ["Normal", "सामान्य"], "fast": ["Fast", "तेज़"],
	"master_vol": ["Master volume", "मास्टर वॉल्यूम"],
	"music_vol": ["Music volume", "संगीत वॉल्यूम"],
	"sfx_vol": ["Effects volume", "प्रभाव वॉल्यूम"],
	"on": ["ON", "चालू"], "off": ["OFF", "बंद"],
	"c_open": ["Protect token opening", "गोटी खोलने पर सुरक्षा"],
	"c_track": ["Protect main track", "मुख्य रास्ते पर सुरक्षा"],
	"c_lane": ["Protect home lane", "होम लेन पर सुरक्षा"],
	"profile": ["Coins %d  |  Wins %d  |  Games %d", "सिक्के %d  |  जीत %d  |  खेल %d"],
	"turn": ["%s's turn", "%s की बारी"],
	"roll": ["ROLL DICE", "पासा फेंकें"],
	"pick": ["Tap a glowing token", "चमकती गोटी को छुएँ"],
	"six": ["Six! Roll again", "छक्का! फिर से फेंकें"],
	"bonus": ["Extra turn!", "एक और बारी!"],
	"captured": ["TOKEN CAPTURED!", "गोटी मारी गई!"],
	"captured_voice": ["Token captured", "गोटी मारी गई"],
	"no_move": ["NO VALID MOVE", "कोई चाल नहीं"],
	"stack_block": ["STACKING MOVE BLOCKED", "एक ही गोटी पर दो गोटी नहीं"],
	"win_text": ["%s WINS!", "%s जीत गया!"],
	"pause": ["Pause", "रोकें"], "resume": ["Resume", "जारी रखें"],
	"restart": ["Restart", "फिर से शुरू"], "home": ["Home", "होम"],
	"again": ["Play again", "फिर से खेलें"],
	"hud_score": ["Home %d/4  Kills %d", "घर %d/4  मारे %d"],
	"avail": ["Dice", "पासा"],
	"cpu": ["CPU", "कंप्यूटर"],
	"you": ["You", "आप"],
}
const COLOR_NAMES := [["Red", "Green", "Yellow", "Blue"], ["लाल", "हरा", "पीला", "नीला"]]

func _ready() -> void:
	load_all()

func li() -> int:
	return 1 if lang == "hi" else 0

func tx(key: String, args: Array = []) -> String:
	var s: String = S[key][li()] if S.has(key) else key
	if args.is_empty():
		return s
	return s % args

func color_name(pl: int, is_cpu := false) -> String:
	var n: String = COLOR_NAMES[li()][pl]
	return n + (" (" + tx("cpu") + ")" if is_cpu else "")

func load_all() -> void:
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) != OK:
		return
	for k in KEYS:
		if cf.has_section_key("s", k):
			set(k, cf.get_value("s", k))

func save_all() -> void:
	var cf := ConfigFile.new()
	for k in KEYS:
		cf.set_value("s", k, get(k))
	cf.save(SAVE_PATH)
