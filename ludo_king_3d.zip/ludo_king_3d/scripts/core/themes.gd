class_name Themes
extends RefCounted
## 16 themes. Row: name_en, name_hi, bg, frame, board, cell, [red,green,yellow,blue],
## metallic, roughness, dice colour, pip colour, token shape (0 pawn,1 diamond,2 coin), neon glow

const DATA := [
	["Classic Wooden", "क्लासिक लकड़ी", "2b1a0e", "5a3a1e", "c9a36a", "f1e0b8", ["d62828", "2a9d3f", "f2c200", "1d6fd6"], 0.1, 0.7, "fff8e7", "222222", 0, false],
	["Royal Gold", "रॉयल गोल्ड", "1a1205", "b8860b", "e8c76a", "fff3c4", ["c1121f", "2d6a4f", "e9b800", "1b4965"], 0.8, 0.25, "f4d35e", "4a2c00", 2, false],
	["Diamond", "डायमंड", "0b1a2b", "9ecae1", "d8f1ff", "ffffff", ["ff4d6d", "2ec4b6", "ffd166", "4361ee"], 0.9, 0.08, "e8f7ff", "112233", 1, false],
	["Neon Cyber", "नियॉन साइबर", "05010f", "1a1a3a", "0d0d26", "1b1b45", ["ff0055", "00ff88", "ffee00", "00b3ff"], 0.6, 0.2, "14142e", "00ffd5", 2, true],
	["Dark AMOLED", "डार्क AMOLED", "000000", "111111", "050505", "1a1a1a", ["e63946", "2ecc71", "f1c40f", "3498db"], 0.3, 0.5, "1c1c1c", "eeeeee", 0, false],
	["Marble", "मार्बल", "2a2a30", "8a8a92", "e9e6df", "fbfaf7", ["b5343c", "3f8f5a", "d4a72c", "3a63b0"], 0.15, 0.15, "ffffff", "222222", 0, false],
	["Galaxy Space", "गैलेक्सी स्पेस", "07031a", "2b1a5a", "1a0f40", "2c1c66", ["ff5ea8", "3ef0b5", "ffd84d", "6c8cff"], 0.7, 0.2, "24104f", "e0d0ff", 1, true],
	["Luxury Gold", "लक्ज़री गोल्ड", "120d02", "8a6a14", "2a2008", "d4af37", ["9d0208", "1b4332", "ffba08", "023e8a"], 0.9, 0.2, "d4af37", "2a1a00", 2, false],
	["Royal Blue", "रॉयल ब्लू", "050c26", "1d3a8a", "17306e", "dbe7ff", ["e63946", "2a9d8f", "ffb703", "4895ef"], 0.3, 0.4, "1d3a8a", "ffffff", 0, false],
	["Emerald Green", "एमरल्ड ग्रीन", "03160d", "0b5a34", "0f7a45", "d9f7e6", ["d90429", "06d6a0", "ffd60a", "118ab2"], 0.4, 0.3, "0b5a34", "e8fff3", 1, false],
	["Sunset", "सनसेट", "2b0f1e", "8a2e3c", "ff8c5a", "ffe3c9", ["e63946", "52b788", "ffbe0b", "5e60ce"], 0.1, 0.6, "ff7b54", "ffffff", 0, false],
	["Candy", "कैंडी", "ffd6ec", "ff8ac2", "ffc2e2", "fff0f8", ["ff4f81", "5fd068", "ffd23f", "5aa7ff"], 0.0, 0.3, "ffe0f0", "ff3e8e", 2, false],
	["Nature", "प्रकृति", "1e3a1a", "5a3e22", "6bbf59", "e6f5d0", ["c0392b", "27ae60", "f39c12", "2980b9"], 0.0, 0.8, "f1e6c8", "3b2a14", 0, false],
	["Fire and Ice", "फायर एंड आइस", "0a0f1f", "40506b", "22304d", "dfeaff", ["ff3b1f", "34d1bf", "ffb000", "3a86ff"], 0.5, 0.2, "1b2a49", "ff7a1a", 1, true],
	["Modern Glass", "मॉडर्न ग्लास", "12202e", "5f7d95", "9fb8cc", "e8f2f8", ["ff6b6b", "4ecdc4", "ffe66d", "5c7cfa"], 0.1, 0.05, "cfe8f6", "1d3557", 2, false],
	["Black & Gold", "ब्लैक एंड गोल्ड", "000000", "d4af37", "0b0b0b", "2a2a2a", ["b3001b", "1e7a46", "ffd700", "1b4fb5"], 0.85, 0.2, "0b0b0b", "d4af37", 2, false],
]

static func count() -> int:
	return DATA.size()

static func get_theme(i: int) -> Dictionary:
	var d: Array = DATA[clampi(i, 0, DATA.size() - 1)]
	var cols := []
	for h in d[6]:
		cols.append(Color(h))
	return {
		"name": d[0] if Settings.lang == "en" else d[1],
		"bg": Color(d[2]), "frame": Color(d[3]), "board": Color(d[4]), "cell": Color(d[5]),
		"p": cols, "metal": d[7], "rough": d[8], "dice": Color(d[9]), "pip": Color(d[10]),
		"shape": d[11], "glow": d[12],
	}
