extends Node
## Autoload "AudioMgr": sound effects pool, looping music, vibration, optional spoken voice (TTS).

var pool: Array = []
var cache := {}
var music_player: AudioStreamPlayer

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in 8:
		var p := AudioStreamPlayer.new()
		add_child(p)
		pool.append(p)
	music_player = AudioStreamPlayer.new()
	add_child(music_player)

func _get_stream(n: String) -> AudioStream:
	if not cache.has(n):
		var path := "res://audio/%s.wav" % n
		cache[n] = load(path) if ResourceLoader.exists(path) else null
	return cache[n]

func play(n: String, vol := 1.0) -> void:
	if not Settings.sfx_on:
		return
	var s := _get_stream(n)
	if s == null:
		return
	for p in pool:
		if not p.playing:
			p.stream = s
			p.volume_db = linear_to_db(maxf(0.0001, Settings.master * Settings.sfx * vol))
			p.play()
			return

func start_music() -> void:
	if music_player.playing:
		apply_volumes()
		return
	var s = load("res://audio/music.wav")
	if s == null:
		return
	var st: AudioStreamWAV = s.duplicate()
	st.loop_mode = AudioStreamWAV.LOOP_FORWARD
	st.loop_begin = 0
	st.loop_end = st.data.size() / 2
	music_player.stream = st
	apply_volumes()
	music_player.play()

func apply_volumes() -> void:
	music_player.volume_db = linear_to_db(maxf(0.0001, Settings.master * Settings.music * 0.6))
	music_player.stream_paused = not Settings.music_on

func vibrate(ms := 60) -> void:
	if Settings.vibration:
		Input.vibrate_handheld(ms)

## Speaks a short line if the phone has a voice for the chosen language.
func speak(text: String) -> void:
	if not Settings.sfx_on:
		return
	var code := "hi" if Settings.lang == "hi" else "en"
	var voices := DisplayServer.tts_get_voices_for_language(code)
	if voices.size() > 0:
		DisplayServer.tts_stop()
		DisplayServer.tts_speak(text, voices[0], int(60 * Settings.master))
