class_name AIPlayer
extends RefCounted
## level 0 easy (random) | 1 medium (capture/open/home) | 2 expert (adds safety + danger awareness)
## Only ever picks from the already-legal token list, so it can never make an illegal move.

static func choose(level: int, tokens: Array, pl: int, dice: int, legal: Array, rng: RandomNumberGenerator) -> int:
	if legal.size() == 1 or level == 0:
		return legal[rng.randi_range(0, legal.size() - 1)]
	var best: int = legal[0]
	var best_score := -1.0e9
	for idx in legal:
		var s := _score(level, tokens, pl, idx, dice) + rng.randf() * (6.0 if level == 1 else 1.0)
		if s > best_score:
			best_score = s
			best = idx
	return best

static func _score(level: int, tokens: Array, pl: int, idx: int, dice: int) -> float:
	var from: int = tokens[pl][idx]
	var dest := GameRules.destination(from, dice)
	var s := 0.0
	if from == GameRules.BASE:
		s += 40.0
	if GameRules.is_on_track(dest) and not GameRules.is_safe(pl, dest):
		if _opponent_at(tokens, pl, GameRules.global_cell(pl, dest)):
			s += 100.0
	if dest == GameRules.FINISHED:
		s += 80.0
	elif GameRules.is_in_home_lane(dest):
		s += 50.0
	s += dest * 0.4
	if level >= 2:
		if GameRules.is_safe(pl, dest):
			s += 25.0
		if _in_danger(tokens, pl, from):
			s += 20.0
		if _in_danger(tokens, pl, dest) and not GameRules.is_safe(pl, dest):
			s -= 35.0
	return s

static func _opponent_at(tokens: Array, pl: int, cell: int) -> bool:
	for o in 4:
		if o == pl:
			continue
		for p in tokens[o]:
			if GameRules.global_cell(o, p) == cell:
				return true
	return false

static func _in_danger(tokens: Array, pl: int, p: int) -> bool:
	if not GameRules.is_on_track(p) or GameRules.is_safe(pl, p):
		return false
	var g := GameRules.global_cell(pl, p)
	for o in 4:
		if o == pl:
			continue
		for q in tokens[o]:
			var h := GameRules.global_cell(o, q)
			if h == -1:
				continue
			var d := (g - h + GameRules.TRACK_LEN) % GameRules.TRACK_LEN
			if d >= 1 and d <= 6:
				return true
	return false
