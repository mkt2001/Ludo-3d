class_name GameRules
extends RefCounted
## Pure rules. No UI, no animation. One token position = "progress":
## -1 base | 0..50 common track (0 = own start cell) | 51..55 home lane | 56 finished

const TRACK_LEN := 52
const BASE := -1
const LAST_TRACK := 50
const HOME_LANE_START := 51
const FINISHED := 56
const INVALID := -2
const START_OFFSET := [0, 13, 26, 39]          # Red, Green, Yellow, Blue
const SAFE_CELLS := [0, 8, 13, 21, 26, 34, 39, 47]

static func is_on_track(p: int) -> bool:
	return p >= 0 and p <= LAST_TRACK

static func is_in_home_lane(p: int) -> bool:
	return p >= HOME_LANE_START and p < FINISHED

static func global_cell(player: int, p: int) -> int:
	if not is_on_track(p):
		return -1   # base / home lane / finished never share cells across players
	return (START_OFFSET[player] + p) % TRACK_LEN

static func is_safe(player: int, p: int) -> bool:
	var c := global_cell(player, p)
	return c != -1 and SAFE_CELLS.has(c)

## Destination ignoring stacking. INVALID if the move is impossible.
static func destination(p: int, dice: int) -> int:
	if p == FINISHED:
		return INVALID
	if p == BASE:
		return 0 if dice == 6 else INVALID
	var d := p + dice
	return d if d <= FINISHED else INVALID   # exact roll needed for home

## tokens[player][i] -> progress. Applies a move, returns {dest, captured:[[pl,i],..], finished}
static func apply_move(tokens: Array, player: int, idx: int, dice: int) -> Dictionary:
	var dest := destination(tokens[player][idx], dice)
	assert(dest != INVALID)
	tokens[player][idx] = dest
	var captured := []
	if is_on_track(dest) and not is_safe(player, dest):
		var cell := global_cell(player, dest)
		for pl in tokens.size():
			if pl == player:
				continue
			for j in tokens[pl].size():
				if global_cell(pl, tokens[pl][j]) == cell:
					tokens[pl][j] = BASE
					captured.append([pl, j])
	return {"dest": dest, "captured": captured, "finished": dest == FINISHED}

## Extra turn after a 6, a capture, or reaching home.
static func grants_extra_turn(dice: int, result: Dictionary) -> bool:
	return dice == 6 or not result["captured"].is_empty() or result["finished"]

static func has_won(own: Array) -> bool:
	for p in own:
		if p != FINISHED:
			return false
	return true
