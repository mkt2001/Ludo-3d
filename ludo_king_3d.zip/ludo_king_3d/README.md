# Ludo King 3D – Grand Master Edition (Godot 4.3)

## APK kaise banayein (mobile se bhi)
1. GitHub par naya repo banao, is zip ke andar ka saara content repo ke root me upload karo (project.godot root me hona chahiye).
2. Actions tab -> "Build Android APK" -> Run workflow (ya push karte hi chalega).
3. Run poora hone par "Artifacts" se `LudoKing3D-apk` download karo.
4. Agar build fail ho to log ka last error mujhe bhej do, main fix kar dunga.

## Kya-kya hai
- 3D board (16 themes), 3D dice (pips ke saath), 4 tarah ke token designs
- 2/3/4 players, Computer (Easy/Medium/Expert) ya Pass & Play
- Anti-Stack dice (Classic / Anti-Stack / Custom), dice info panel (available / blocked)
- Sirf active player ke ghar ke paas dice + glowing border
- Capture, safe cells, home lane, exact roll, extra turn, winner confetti
- Original sounds + music (tools/make_audio.py se bante hain), vibration, Hindi/English
- Coins / wins save hote hain

## Abhi shamil NAHI (honestly)
Online multiplayer, tournament, shop, daily rewards, leaderboard, per-theme alag sounds.
