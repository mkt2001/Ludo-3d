"""Python mirror of the GDScript logic, used only to sanity-check the algorithm here
(Godot is not installed in this environment). Run: python3 tests/reference_check.py"""
import random
BASE,FIN,INV=-1,56,-2
def dest(p,d):
    if p==FIN: return INV
    if p==BASE: return 0 if d==6 else INV
    return p+d if p+d<=FIN else INV
def stack(own,i,de): return de!=FIN and own[i]!=BASE and any(j!=i and own[j]==de for j in range(len(own)))
def blocked(own,d):
    c=0
    for i in range(len(own)):
        de=dest(own[i],d)
        if de==INV: continue
        c+=1
        if not stack(own,i,de): return False
    return c>0
def calc(own):
    a=[d for d in range(1,7) if not blocked(own,d)]
    return a,[d for d in range(1,7) if blocked(own,d)]
assert not blocked([10,14,20,-1],4) and 0 not in [i for i in range(4) if dest([10,14,20,-1][i],4)!=INV and not stack([10,14,20,-1],i,dest([10,14,20,-1][i],4))]
assert calc([51,54,56,56])[1]==[3]
random.seed(1); bad=0
for _ in range(200000):
    own=[random.choice([-1]+list(range(0,57))) for _ in range(4)]
    # only valid states: no two tokens share a cell except finished/base
    seen=[p for p in own if p not in (-1,56)]
    if len(seen)!=len(set(seen)): continue
    a,b=calc(own)
    for d in a:
        # available => either some non-stacking move exists, or no move at all by normal rules
        moves=[i for i in range(4) if dest(own[i],d)!=INV]
        if moves and all(stack(own,i,dest(own[i],d)) for i in moves): bad+=1
    for d in b:
        moves=[i for i in range(4) if dest(own[i],d)!=INV]
        if not moves or any(not stack(own,i,dest(own[i],d)) for i in moves): bad+=1
print("violations:",bad)
assert bad==0
print("mandatory case OK, blocked-case OK, fuzz OK")
