extends SceneTree
## Run: godot --headless -s tests/test_anti_stack.gd
var fails := 0
func check(name: String, cond: bool) -> void:
	if not cond:
		fails += 1
		printerr("FAIL: ", name)
	else:
		print("ok: ", name)

func _init() -> void:
	var m := AntiStackDiceManager.new()
	# Mandatory case: A=10, B=14, C=20, D=base, dice 4 -> still available (others can move)
	var own := [10, 14, 20, -1]
	check("A cannot move 4", not (0 in m.legal_tokens(own, 4)))
	check("C can move 4", 2 in m.legal_tokens(own, 4))
	check("4 available", not m.is_blocked(own, 4))
	# All tokens would stack -> blocked: A=10,B=14 only movers, C finished, D finished
	var own2 := [10, 14, 56, 56]
	check("B->18 free so 4 available", not m.is_blocked(own2, 4))
	var own3 := [10, 14, 18, 56]   # 4: A->14 stack, B->18 stack, C->22 free
	check("4 available via C", not m.is_blocked(own3, 4))
	var own4 := [52, 54, 56, 56]   # 2: 52->54 stack, 54->56 ok (finish) -> available
	check("exact home finish", not m.is_blocked(own4, 2))
	var own5 := [51, 52, 53, 56]   # 1: 51->52,52->53 stack, 53->54 free
	check("home lane", not m.is_blocked(own5, 1))
	var own6 := [54, 55, 56, 56]   # 1: 54->55 stack; 55->56 finish ok
	check("finish not a stack", not m.is_blocked(own6, 1))
	var own7 := [53, 54, 56, 56]   # 1: 53->54 stack; 54->55 ok
	check("one free", not m.is_blocked(own7, 1))
	var own8 := [0, -1, 56, 56]    # 6: open blocked (start occupied), 0->6 ok
	check("6 via track move", not m.is_blocked(own8, 6))
	var own9 := [0, -1, -1, -1]    # 6: 0->6 free -> available
	check("open ok", not m.is_blocked(own9, 6))
	# Fully blocked value: A=10, B=14, others base -> dice 4: A stacks, B->18 free => not blocked
	# Real block: only two movable tokens in a chain A=51,B=52, rest finished, dice 1: 51->52 stack, 52->53 free => available
	# True block: A=0, B=-1(base), C,D finished, dice 6 -> A->6 free. Use A=50,B=55? dice 1: 50->51 free.
	var own10 := [-1, 0, 56, 56]   # 6: base->0 stacks with B, B->6 free
	check("6 available", not m.is_blocked(own10, 6))
	var own11 := [-1, 5, 56, 56]
	check("no block when free", m.calculate(own11)["blocked"].is_empty())
	# Real block: A=51, B=54, C/D finished, dice 3: A->54 stacks, B overshoots (57)
	var own12 := [51, 54, 56, 56]
	check("3 blocked", m.is_blocked(own12, 3))
	check("blocked list is [3]", m.calculate(own12)["blocked"] == [3])
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	var never_blocked := true
	for k in 500:
		if m.roll(own12, rng)["value"] == 3: never_blocked = false
	check("roll never returns blocked 3", never_blocked)
	# Classic mode never blocks
	m.mode = AntiStackDiceManager.Mode.CLASSIC
	check("classic no block", m.calculate([10, 14, 20, -1])["blocked"].is_empty())
	quit(1 if fails > 0 else 0)
