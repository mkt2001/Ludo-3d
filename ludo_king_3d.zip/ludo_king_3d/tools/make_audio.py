"""Generates all original sound effects + background music (no copyrighted audio). Run: python3 tools/make_audio.py"""
import wave, struct, math, random, os
SR = 22050
random.seed(5)
def save(name, samples):
    os.makedirs("audio", exist_ok=True)
    with wave.open(f"audio/{name}.wav", "w") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(b"".join(struct.pack("<h", int(max(-1, min(1, s)) * 32000)) for s in samples))
def tone(freq, dur, vol=0.5, kind="sine", decay=6.0, attack=0.005, f_end=None):
    n = int(SR * dur); out = []; ph = 0.0
    for i in range(n):
        t = i / SR
        f = freq if f_end is None else freq + (f_end - freq) * (i / n)
        ph += 2 * math.pi * f / SR
        if kind == "sine": s = math.sin(ph)
        elif kind == "tri": s = 2 / math.pi * math.asin(math.sin(ph))
        elif kind == "square": s = 1.0 if math.sin(ph) > 0 else -1.0
        else: s = random.uniform(-1, 1)
        env = min(1, t / attack) * math.exp(-decay * t)
        out.append(s * env * vol)
    return out
def mix(*tracks):
    n = max(len(t[1]) + int(t[0] * SR) for t in tracks); out = [0.0] * n
    for off, tr in tracks:
        o = int(off * SR)
        for i, s in enumerate(tr): out[o + i] += s
    return out
def lowpass(x, k=0.3):
    y = []; p = 0.0
    for s in x: p += k * (s - p); y.append(p)
    return y
N = lambda d, v, dec: tone(0, d, v, "noise", dec)
save("click", tone(1400, 0.06, 0.4, "sine", 40))
rattle = [(i * 0.045 + random.uniform(0, 0.02), lowpass(N(0.05, 0.6, 50), 0.5)) for i in range(14)]
save("dice_roll", mix(*rattle))
save("dice_land", mix((0, tone(110, 0.25, 0.8, "sine", 14)), (0, lowpass(N(0.12, 0.5, 30), 0.4))))
save("move", tone(620, 0.07, 0.45, "sine", 35))
save("jump", tone(380, 0.16, 0.5, "tri", 12, f_end=820))
save("capture", mix((0, tone(70, 0.5, 0.95, "sine", 7)), (0, lowpass(N(0.25, 0.9, 14), 0.5)),
                    (0.02, tone(900, 0.45, 0.5, "square", 6, f_end=180))))
save("home", mix(*[(i * 0.1, tone(f, 0.25, 0.45, "tri", 8)) for i, f in enumerate([880, 740, 620, 520, 440])]))
save("six", mix(*[(i * 0.07, tone(f, 0.3, 0.4, "tri", 6)) for i, f in enumerate([523, 659, 784, 1047])]))
save("turn", mix((0, tone(660, 0.18, 0.4, "sine", 10)), (0.12, tone(880, 0.25, 0.4, "sine", 8))))
save("win", mix(*[(i * 0.16, tone(f, 0.7, 0.5, "tri", 3)) for i, f in enumerate([523, 659, 784, 1047, 784, 1047, 1319])]))
save("lose", mix(*[(i * 0.25, tone(f, 0.5, 0.45, "tri", 4)) for i, f in enumerate([440, 392, 349, 262])]))
# background music: 4 chords x 4 s = 16 s loop, soft arpeggio + pad
chords = [(220, 261.6, 329.6), (174.6, 220, 261.6), (261.6, 329.6, 392), (196, 246.9, 293.7)]
tracks = []
for ci, ch in enumerate(chords):
    t0 = ci * 4.0
    for f in ch: tracks.append((t0, tone(f / 2, 4.0, 0.10, "sine", 0.35, attack=0.4)))
    for k in range(16):
        tracks.append((t0 + k * 0.25, tone(ch[k % 3] * 2, 0.5, 0.16, "tri", 5)))
m = mix(*tracks)[: SR * 16]
save("music", [s * 0.8 for s in m])
print("audio done:", sorted(os.listdir("audio")))
